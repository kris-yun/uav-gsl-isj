#pragma once

#include "gsl_server/algorithms/Common/Occupancy.hpp"
#include "internal/UI.hpp"
#include <gsl_server/algorithms/Common/Algorithm.hpp>
#include <gsl_server/algorithms/PMFS/internal/HitProbKernel.hpp>
#include <gsl_server/algorithms/PMFS/internal/HitProbability.hpp>
#include <gsl_server/algorithms/PMFS/internal/Simulations.hpp>
#include <gsl_server/algorithms/Semantics/SemanticPMFS/MovingStateSemanticPMFS.hpp>
#include <gsl_server/algorithms/Semantics/SemanticPMFS/SemanticPMFSPubs.hpp>
#include <gsl_server/algorithms/Semantics/SemanticPMFS/SemanticPMFSSettings.hpp>
#include <gsl_server/algorithms/Semantics/Semantics/Common/ISemantics.hpp>
#include <vector>

namespace GSL
{
    class SemanticPMFS : public Algorithm
    {
        template <typename T>
        using Grid = Grid2D<T>;
        using HitProbability = PMFS_internal::HitProbability;
        using HitProbKernel = PMFS_internal::HitProbKernel;
        using HashSet = std::unordered_set<Vector2Int>;

        friend class MovingStateSemanticPMFS;
        IF_GUI(friend class SemanticPMFS_internal::UI;)

    public:
        SemanticPMFS(std::shared_ptr<rclcpp::Node> _node);
        void Initialize() override;
        void OnUpdate() override;

    private:
        GSLResult checkSourceFound() override;
        void declareParameters() override;
        void onGetMap(const nav_msgs::msg::OccupancyGrid::SharedPtr msg) override;
        void processGasAndWindMeasurements(double concentration, double windSpeed, double windDirection) override;
        void saveResultsToFile(GSLResult result) override;
        float gasCallback(olfaction_msgs::msg::GasSensor::SharedPtr msg) override;

        void updateSourceFromSemantics();

        void createClassMap2D();
        void createClassMapVoxeland();
        void logProgressionAndVisualize();

        template <typename T>
        Grid2D<T> AsGrid(std::vector<T>& vec, std::vector<Occupancy>& occupancy)
        {
            return Grid<T>(vec, occupancy, gridMetadata);
        }

    private:
        std::unique_ptr<ISemantics> semantics;
        std::vector<double> combinedSourceProbability;

        //-------------PMFS-------------
        Grid2DMetadata gridMetadata;
        std::vector<double> sourceProbabilityPMFS;
        std::vector<double> sourceProbSemantics;
        std::vector<HitProbability> hitProbability;
        std::vector<Occupancy> navigationOccupancy;
        std::vector<Occupancy> simulationOccupancy;
        std::vector<Vector2> estimatedWindVectors;

        PMFS_internal::Simulations simulations;

        //-------------Data-------------
        SemanticPMFS_internal::Settings settings;
        SemanticPMFS_internal::PublishersAndSubscribers pubs;

        //-------------Utils-------------
        std::optional<VisibilityMap> visibilityMap;
        uint iterationsCounter = 0;
        bool paused = false;
        IF_GUI(SemanticPMFS_internal::UI ui;)
    };
} // namespace GSL