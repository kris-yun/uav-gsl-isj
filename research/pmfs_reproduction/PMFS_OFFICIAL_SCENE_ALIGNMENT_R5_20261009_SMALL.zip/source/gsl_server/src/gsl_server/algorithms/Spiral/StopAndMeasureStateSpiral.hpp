#pragma once
#include <gsl_server/algorithms/Common/States/StopAndMeasureState.hpp>

namespace GSL
{
    class StopAndMeasureStateSpiral : public StopAndMeasureState
    {
    public:
        StopAndMeasureStateSpiral(Algorithm* _algorithm);

        void addGasReading(double concentration) override;
        double getSumOfLocalMaxima();

        double intervalLength;

    protected:
        void OnEnterState(State* previous) override;

    private:
        class Spiral* spiral;

        struct MeasureInterval
        {
            std::vector<double> gasMeasurements;
        };
        std::vector<MeasureInterval> intervals;
    };
} // namespace GSL