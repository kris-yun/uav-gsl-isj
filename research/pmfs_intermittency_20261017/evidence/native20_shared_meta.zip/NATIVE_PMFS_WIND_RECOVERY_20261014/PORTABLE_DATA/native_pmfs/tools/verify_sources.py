from pathlib import Path
import hashlib, json

root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    path=(root/item['path']).resolve()
    assert path.is_relative_to(root)
    payload=path.read_bytes()
    assert len(payload)==item['bytes']
    assert hashlib.sha256(payload).hexdigest()==item['sha256'],item['path']
objects=json.loads((root/'UPSTREAM_GIT_OBJECTS.json').read_text(encoding='utf-8'))
count=0
for item in objects['entries']:
    if item['type']!='blob':continue
    data=(root/'official_upstream'/item['path']).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_object_sha1'],item['path']
    count+=1
assert count==147
print(json.dumps({'status':'PASS_SOURCE_IDENTITY_ONLY','upstream_git_blobs_verified':count,
                  'manifest_files_verified':len(manifest['files']),
                  'commit':objects['commit'],'new_ROS':0,'new_physics':0},indent=2))
