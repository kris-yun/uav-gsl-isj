# 请先用原生PMFS源码重新定位创新边界

这份包补充原生PMFS完整算法实现、共同ROS基础代码和版本对照。官方仓库为 [MAPIRlab/GasSourceLocalization](https://github.com/MAPIRlab/GasSourceLocalization)，旧地址 `MAPIRlab/Gas-Source-Localization` 会跳转到这里。README明确列有PMFS并链接[论文](https://arxiv.org/abs/2304.08879)。

本次核验 `humble` 分支HEAD为 `4e141e162551e674f2f30ddb8859136c72139aac`，与我们本地R5的SOURCE_PIN中GSL字段一致。这里交付的是该固定提交的上游代码，不是声称它与2024年论文实验二进制逐字相同。

## 必须补充到上一轮研究要求中的事实

**原生PMFS并非只在每个区域中心放一个固定点源。它已经有区域内随机释放和按源评分做四叉树细化。**

具体证据位于 `official_upstream/gsl_server/src/gsl_server/algorithms/PMFS/internal/Simulations.cpp`：

- `runSimulation`，第199行起：用四叉树node构建SimulationSource，并调用模拟。
- `simulateSourceInPosition`，第285行起：释放粒子时调用 `source.getPoint()`；第382行起的 `getPoint` 在Quadtree模式下，在区域范围内随机取释放位置。Point模式才返回固定点。
- `updateSourceProbability`，第82行起：先运行粗区域，再按score排序，选择 `refineFraction` 比例区域做 `subdivide`，继续模拟子区域。
- `sourceProbFromMaps`，第231行起：逐自由格比较测量hit概率图与模拟hitMap并相乘；`probabilityFromSingleCell` 结合置信度，`probabilitySingleFrequency` 使用频率差形成因子。

因此，我们45固定代表源物理参考库的响应缺口，不能直接当作原生PMFS已被证明存在的同一个缺口。新4份精确源参考仍是有价值的台架诊断，但没有直接测试上述原生区域随机释放与细化流程。

我上一份要求把“区域内响应表示”列为可研究方向，需要与这里已有机制逐项核对。**区域建模、自适应细化、多分辨率、候选模拟本身都不能直接当作新增创新点。**

## 下一轮请实际做的核对

1. 沿源码列出原生PMFS的输入、地图状态、源证据、区域细化和行动接口；把我们的45源参考适配器画在旁边，逐项说明替换或省略了什么。
2. 对想新增的模块，明确它在原生PMFS的哪个函数前后接入、接收什么部署可得输入、返回什么被下游使用的输出，以及新增数学运算。若原生已有等价操作，就不能作为新贡献。
3. 可以核查一个具体的开放问题：原生“区域内每次释放随机取点形成hit图”，与“一个固定但未知点源的条件响应在区域内积分”在当前评分与整段历史中是否等价。这里仅提出需要推导和实验区分的问题，没有认定它不等价、认定原方法错误或认定创新成立。若研究它，要给公式、最小反例和公平对照。
4. 保留普通细化、原生细化、常规稳健评分和几何覆盖等强对照。新增物理库、更多分辨率或修复适配器带来的收益单独归因；核心模块必须有同预算消融。
5. 原生PMFS不是只有二值浓度阈值：阈值后的hit概率传播、置信度、风估计、在线区域模拟、全图源评分与行动价值都在代码中。不要把我们简化binary规划对照当完整PMFS。
6. 结合前面的补充数据先做最小可证伪检验，交付代码和结果。若现有离线数据不包含某个原生状态，明确列缺失状态；不要把补出原生实现等同于创新，也不要围绕两个已见世界扩大调参。

## 交付范围

`official_upstream/` 包含该提交下完整 `gsl_server`、`gsl_actions` 及根目录文档，共147个受版本控制文件，所有文件均核验Git blob身份。PMFS内部实现已包含。

第三方DDA与StateMachine子模块只记录固定提交，未展开；原论文环境、CFD和气体仿真大文件不在此代码包。`UPSTREAM_ENVIRONMENT_CONFIG_PATHS.json` 给出官方配置路径索引，当前树含A–E每场景4个模拟配置；它不自动替换先前冻结的十配置清单。此包支持源码阅读与研究设计，未在本轮编译、运行ROS或重做原生PMFS性能实验。

`local_R5_previous_excerpt/` 保留上次给你的只读源码节选与其来源、补丁；`LOCAL_R5_VS_OFFICIAL.json` 和 `.patch` 列出它相对本固定上游的差异。**SOURCE_PIN一致不等于本地工作树没有修改。**判断原生行为请以 `official_upstream` 为主，判断本地执行行为则另核对真实构建及运行版本。

先运行 `python tools/verify_sources.py`。然后请把“原生已有—适配器近似—拟新增机制—必要证据”四列核对表纳入下一份研究结果，修正任何与源码冲突的创新表述。
