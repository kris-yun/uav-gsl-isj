"""Minimal ROS2 OccupancyGrid CDR decoder; no ROS runtime dependency."""
import struct
import numpy as np
def decode_grid(b):
 if b[:2]!=b'\x00\x01':raise ValueError('Expected little-endian ROS2 CDR')
 pos=4
 def read(fmt,align):
  nonlocal pos
  pos+=(-(pos-4))%align;values=struct.unpack_from('<'+fmt,b,pos);pos+=struct.calcsize('<'+fmt);return values
 sec,ns=read('iI',4);n,=read('I',4);frame=b[pos:pos+n-1].decode();pos+=n
 loadsec,loadns=read('iI',4);res,width,height=read('fII',4);origin=read('7d',8);n,=read('I',4)
 if n!=width*height or pos+n!=len(b):raise ValueError('OccupancyGrid size mismatch')
 a=np.frombuffer(b,np.int8,n,pos).reshape(height,width).copy()
 return {'stamp_ns':sec*10**9+ns,'frame_id':frame,'resolution':res,'width':width,'height':height,'origin_xyz':origin[:3],'quaternion_xyzw':origin[3:]},a
