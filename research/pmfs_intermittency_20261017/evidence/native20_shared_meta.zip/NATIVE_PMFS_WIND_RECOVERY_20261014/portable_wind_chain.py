"""Verify actual consumed wind from a portable CASE_INDEX.json; no ROS installation."""
from pathlib import Path
import csv,io,json,hashlib
import numpy as np
from cdr_wind import decode_response
def check(data,out):
 data=Path(data);out=Path(out);out.mkdir(parents=True,exist_ok=False);index=json.loads((data/'CASE_INDEX.json').read_text());groups={a['group']:a for a in index['field_groups']};records=[]
 for entry in index['cases']:
  c=entry['case'];root=data/entry['native_path'];g=groups[entry['group']];header=(data/g['grid_path']).read_text().splitlines()[:4];dims=np.array([int(a) for a in header[2].split()[1:]]);origin=np.array([float(a) for a in header[0].split()[1:]],np.float32);cell=np.float32(header[3].split()[1]);fields={}
  for f in g['fields']:
   p=data/f['path'];b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];a=np.frombuffer(b[8:],'<f4').reshape(-1,3);assert len(a)==int(np.prod(dims)) and np.isfinite(a).all() and np.any(a!=0);assert hashlib.sha256(b[8:]).hexdigest()==f['native_loaded_xyz_sha256'];fields[f['frame']]=a
  queries=[json.loads(a) for a in (root/'runtime/service_queries.jsonl').read_text().splitlines() if a.strip()];queries=[a for a in queries if a['kind']=='WindPosition'];trace=list(csv.DictReader((root/'runtime/physical_clock_trace.csv').open()));updates=[]
  for done in sorted((root/'runtime/updates').glob('*/COMPLETE.txt')):
   prefix=done.parent;m=json.loads((prefix/'metadata.json').read_text());rows=list(csv.DictReader((prefix/'input.csv').open()));free=[a for a in rows if a['occupancy']=='1'];uv=np.array([[float(a['u']),float(a['v'])] for a in free]);choices=[a for a in queries if len(a['x'])==len(free) and a['response_ns']<=m['stamp_ns']+150000000];assert choices,(c,prefix.name,'missing grid query');q=max(choices,key=lambda a:a['response_ns']);service=decode_response(bytes.fromhex(q['response_cdr_hex']));assert np.array_equal(uv,service[:,:2]),(c,prefix.name,'native input differs from service')
   near=[a for a in trace if a['reason']=='wind_service' and q['request_ns']-150000000<=int(a['receipt_ros_ns'])<=q['response_ns']+150000000];wi=sorted({int(a['wind_index']) for a in near});assert len(wi)==1,(c,prefix.name,'ambiguous physical wind index',wi);xyz=np.asarray(np.c_[q['x'],q['y'],q['z']],np.float32);ijk=np.trunc((xyz-origin)/cell).astype(int);assert np.all(ijk>=0) and np.all(ijk<dims);flat=ijk[:,0]+dims[0]*(ijk[:,1]+dims[1]*ijk[:,2]);expected=fields[wi[0]][flat];assert np.array_equal(expected,service),(c,prefix.name,'physical3D field differs from service');updates.append({'update':prefix.name,'wind_index':wi[0],'free_cells':len(free),'max_absolute_error':0.,'nonzero_horizontal_cells':int(np.sum(np.linalg.norm(uv,axis=1)>0))})
  assert updates,(c,'no completed source update');rec={'case':c,'status':'PASS_NATIVE_UV_SERVICE_AND_ACTUAL_XYZ_FIELD','updates':updates};(out/(c+'.json')).write_text(json.dumps(rec,indent=2));records.append(rec)
 assert len(records)==20
 result={'status':'PASS_ALL20_ACTUAL_WIND_CHAINS','cases':records,'scope':'Actual input identity, not CFD validity or independent algorithm gain.'};(out/'SUMMARY.json').write_text(json.dumps(result,indent=2));return result
if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('--data',required=True,type=Path);a.add_argument('--out',required=True,type=Path);args=a.parse_args();r=check(args.data,args.out);print(json.dumps({'status':r['status'],'cases':len(r['cases'])}))
