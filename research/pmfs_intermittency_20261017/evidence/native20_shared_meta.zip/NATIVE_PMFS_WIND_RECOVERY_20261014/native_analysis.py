"""Read-only analysis of completed native case traces; no thresholds retuned."""
from pathlib import Path
import json,csv,io,math,re,hashlib,zipfile,struct,datetime,argparse
import numpy as np
from scipy.special import expit,logsumexp

S=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Directory:
 def __init__(self,root):self.root=Path(root)
 def read(self,name):return (self.root/name).read_bytes()
 def names(self):return [p.relative_to(self.root).as_posix() for p in self.root.rglob('*') if p.is_file()]
class Archive:
 def __init__(self,path,prefix):self.z=zipfile.ZipFile(path);self.prefix=prefix+'/'
 def read(self,name):return self.z.read(self.prefix+name)
 def names(self):return [p[len(self.prefix):] for p in self.z.namelist() if p.startswith(self.prefix)]
def logfilepoint(text):
 if not text.strip():return None
 last=text.strip().splitlines()[-1];a=last.split();failed=a[0]=='FAILED';a=a[1:] if failed else a
 if len(a)!=6:return {'raw':last,'parse_status':'UNKNOWN_FORMAT'}
 x=list(map(float,a));return {'raw':last,'native_recorded_failure':failed,'navigation_time_s':x[0],'search_time_s':x[1],'mean_error_m':x[2],'best5pct_error_m':x[3],'movement_iterations':int(x[4]),'variance_m2':x[5]}
def ln_value(s):
 if float(s)!=0:return math.log(float(s))
 if s=='0' or s=='0.0':return -math.inf
 if 'e' in s.lower():
  m,e=s.lower().split('e');return math.log(float(m))+int(e)*math.log(10)
 from decimal import Decimal
 return float(Decimal(s).ln())

def analyze(case,meta,reader):
 names=reader.names();tx=lambda n:reader.read(n).decode('utf8');rows=lambda n:list(csv.DictReader(io.StringIO(tx(n))))
 status=json.loads(tx('RUN_RESULT.json'));truth=np.asarray(meta['source_xyz'][:2],float)
 params=tx('runtime/resolved_GSL_parameters.yaml') if 'runtime/resolved_GSL_parameters.yaml' in names else ''
 get=lambda k,default:float(re.search(r'\b'+k+r':\s*([\d.eE+-]+)',params).group(1)) if re.search(r'\b'+k+r':\s*([\d.eE+-]+)',params) else default
 D=get('sourceDiscriminationPower',.3);threshold=get('convergence_thr',1.5);gas_threshold=get('th_gas_present',.1)
 if 'runtime/measurement_events.csv' in names and tx('runtime/measurement_events.csv').strip():events=np.loadtxt(io.StringIO(tx('runtime/measurement_events.csv')),delimiter=',',ndmin=2)
 else:events=np.zeros((0,8))
 us=sorted({n.split('/')[2] for n in names if n.startswith('runtime/updates/') and n.endswith('/COMPLETE.txt')},key=lambda n:int(n.split('_')[-1]));updates=[]
 for un in us:
  root='runtime/updates/'+un+'/';m=json.loads(tx(root+'metadata.json'));inp=rows(root+'input.csv');n=len(inp);free=np.array([int(a['occupancy'])==1 for a in inp]);assert free.sum()==m['free_cells']
  q=np.frombuffer(reader.read(root+'posterior.f64'),'<f8');assert len(q)==n and np.isfinite(q).all() and (q>=0).all() and np.isclose(q[free].sum(),1)
  xy=np.c_[m['origin_x']+(np.arange(n)%m['width']+.5)*m['cell_size'],m['origin_y']+(np.arange(n)//m['width']+.5)*m['cell_size']]
  ij=[int((truth[0]-m['origin_x'])/m['cell_size']),int((truth[1]-m['origin_y'])/m['cell_size'])];inside=0<=ij[0]<m['width'] and 0<=ij[1]<m['height'];ti=ij[0]+ij[1]*m['width'];legal=inside and bool(free[ti])
  mean=q@xy;dist=np.linalg.norm(xy-truth,axis=1);var=float(np.sum(q*np.sum((xy-mean)**2,axis=1)))
  order=np.flatnonzero(free)[np.argsort(-q[free],kind='stable')];cred=order[:np.searchsorted(np.cumsum(q[order]),.9)+1];best=order[:math.ceil(free.sum()*.05)];point=np.sum(q[best,None]*xy[best],axis=0)/q[best].sum()
  raw=rows(root+'raw_cell_scores.csv');lr=np.array([ln_value(a['score']) for a in raw]);qrec=np.zeros(n);qrec[free]=np.exp(lr[free]-logsumexp(lr[free]));parity=float(np.max(np.abs(q-qrec)));assert parity<1e-10
  p=expit(np.array([float(a['logOdds']) for a in inp]));conf=np.array([float(a['confidence']) for a in inp]);cs=rows(root+'candidates.csv');cd={a['candidate_id']:a for a in cs};maps={};errors=[]
  for a in cs:
   h=np.frombuffer(reader.read(root+a['map_file']),'<f4');assert len(h)==n and np.isfinite(h).all();maps[a['candidate_id']]=h
   f=1-D*conf[free]*np.abs(p[free]-h[free]);assert (f>0).all();value=float(np.log(f).sum());errors.append(abs(value-float(a['logscore'])))
  assert max(errors,default=0)<.002
  leaves=[a for a in rows(root+'final_tree.csv') if a['has_children']=='0' and a['node_id'] in cd];bestleaf=max([cd[a['node_id']] for a in leaves],key=lambda a:float(a['logscore']))
  truths=[a for a in leaves if int(a['origin_i'])<=ij[0]<int(a['origin_i'])+int(a['size_i']) and int(a['origin_j'])<=ij[1]<int(a['origin_j'])+int(a['size_j'])] if legal else []
  direct=[];comparison=None;e=events[events[:,0]<=m['stamp_ns']]
  if len(truths)==1:
   tc=cd[truths[0]['node_id']];ht=maps[tc['candidate_id']];hw=maps[bestleaf['candidate_id']]
   delta=np.log(1-D*conf*np.abs(p-hw))-np.log(1-D*conf*np.abs(p-ht))
   for stop in np.unique(e[:,6]):
    a=e[e[:,6]==stop];x,y=a[-1,4:6];i=int((x-m['origin_x'])/m['cell_size']);j=int((y-m['origin_y'])/m['cell_size']);idx=i+j*m['width'];hit=float(np.mean(a[:,1]>gas_threshold))
    if 0<=i<m['width'] and 0<=j<m['height'] and free[idx]:direct.append({'stop':int(stop),'measurements':len(a),'empirical_hit_fraction':hit,'truth_leaf_h':float(ht[idx]),'best_leaf_h':float(hw[idx]),'Brier_best_minus_truth':float((hw[idx]-hit)**2-(ht[idx]-hit)**2),'receiver_xy_m':[x,y]})
   poses=np.unique(e[:,4:6],axis=0);nearest=np.min(np.linalg.norm(xy[:,None,:]-poses[None,:,:],axis=2),axis=1) if len(poses) else np.full(n,np.inf)
   comparison={'truth_final_leaf':tc['candidate_id'],'best_final_leaf':bestleaf['candidate_id'],'same_leaf':tc['candidate_id']==bestleaf['candidate_id'],'native_logscore_best_minus_truth':float(delta[free].sum()),'mean_direct_stop_Brier_best_minus_truth':float(np.mean([a['Brier_best_minus_truth'] for a in direct])) if direct else None,
    'inside_0p5m_sample_neighborhood_logcontrast':float(delta[free&(nearest<=.5)].sum()),'outside_0p5m_sample_neighborhood_logcontrast':float(delta[free&(nearest>.5)].sum()),'direct_stop_diagnostic':direct}
  updates.append({'update':un,'metadata':m,'truth_legal':legal,'truth_cell_index':ti if inside else None,'truth_cell_mass':float(q[ti]) if legal else 0.,'truth_strict_rank':1+int(np.sum(q[free]>q[ti])) if legal else None,
   'within_0p5m_mass':float(q[dist<=.5].sum()),'within_1p5m_mass':float(q[dist<=1.5].sum()),'posterior_mean_xy':mean.tolist(),'posterior_mean_error_m':float(np.linalg.norm(mean-truth)),
   'diagnostic_best5pct_xy':point.tolist(),'diagnostic_best5pct_error_m':float(np.linalg.norm(point-truth)),'variance_m2':var,'variance_threshold':threshold,'concentrated':var<threshold,
   'truth_in90pct_set':bool(legal and ti in cred),'area90pct_free_fraction':len(cred)/int(free.sum()),'native_candidate_calls':len(cs),'max_logscore_recompute_error':max(errors,default=0),'posterior_parity_max_abs_error':parity,
   'source_contrast':comparison})
 original_point=logfilepoint(tx('runtime/native_results.csv')) if 'runtime/native_results.csv' in names else None
 clocks=[]
 for ln in tx('runtime/raw_ros_cdr.jsonl').splitlines():
  a=json.loads(ln)
  if a['topic']=='/clock':
   b=bytes.fromhex(a['cdr_hex']);assert b[:2]==b'\0\1';sec,ns=struct.unpack_from('<iI',b,4);clocks.append(sec*10**9+ns)
 backward=sum(b<a for a,b in zip(clocks,clocks[1:]));assert backward==0
 outcome='SEARCH_HORIZON_REACHED' if status.get('resource_stop_reason')=='SIMULATION_SEARCH_BUDGET_300S' else ('NATIVE_CONVERGED_WITHIN_1P5M' if original_point and original_point.get('best5pct_error_m',math.inf)<=1.5 else 'NATIVE_CONVERGED_OUTSIDE_1P5M') if status.get('localization_success') else 'EXPLICIT_NATIVE_FAILURE' if status.get('result')=='NATIVE_ACTION_RETURNED' else 'ENGINEERING_OR_DATA_INVALID'
 return {'case':case,'status':outcome,'original_native_status':status,'source_xyz_m':meta['source_xyz'],'robot_start_xyz_m':meta.get('robot_start_xyz'),'sensor_xyz_m':meta.get('sensor_xyz'),'source_sensor_height_difference_m':meta['source_xyz'][2]-meta['sensor_xyz'][2] if meta.get('sensor_xyz') else None,
  'official_wind_path':meta.get('official_wind_path'),'native_noise_stdev':get('noiseSTDev',.5),'source_discrimination_power':D,'observed_events':len(events),'positive_events':int(np.sum(events[:,1]>gas_threshold)),'measurement_stops':len(np.unique(events[:,6])),'clock_messages':len(clocks),'clock_backwards':backward,
  'native_returned_point_metrics':original_point,'complete_source_updates':len(updates),'native_candidate_calls':sum(a['native_candidate_calls'] for a in updates),'updates':updates,
  'scope':'One default initialization in this configuration; point metrics use original native log when available, last completed trace estimates are diagnostic only. Direct-stop contrast is not a calibrated replacement likelihood. Capture has I/O costs.'}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);parser.add_argument('--include-previous',action='store_true');a=parser.parse_args();assert not a.out.exists(),'preserve earlier snapshots';a.out.mkdir(parents=True)
 reg=json.loads((S/'CASE_REGISTRY.json').read_text());case_results=[];missing=[]
 for m in reg:
  local=S/'cases'/m['case']
  root=(local if local.exists() else Path(str(m['shared_case_path']).replace('/mnt/hgfs/workspace/','D:/ZYC/A-gas/workspace/')))/'native_execution'
  for retry in sorted(root.parent.glob('native_execution_RETRY*')):
   if (retry/'RUN_RESULT.json').exists() and json.loads((retry/'RUN_RESULT.json').read_text()).get('native_goal_count',0)>0 and (retry/'runtime'/'physical_clock_trace.csv').exists():root=retry
  if (root/'RUN_RESULT.json').exists():
   v=analyze(m['case'],m,Directory(root));v['selected_evidence_directory']=root.name;case_results.append(v);(a.out/(m['case']+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
  else:missing.append(m['case'])
 base=S.parent/'NATIVE_PMFS_FAILURE_DIAGNOSIS_20261014'
 if not base.exists():base=S.parent/'native_closed_loop'
 for c,truth,start,sensor,wind in [('B4',[-3.2,-3.3,-.5],[-.9,.15,-.7],[-.9,.15,-.2],'2,4-1_fast/2,4-1_fast'),('E3',[-4,-1.9,.7],[-3,4.5,.1],[-3,4.5,.6],'W1/wind_at_cell_centers')]:
  m={'source_xyz':truth,'robot_start_xyz':start,'sensor_xyz':sensor,'official_wind_path':wind}
  v=analyze(c,m,Archive(base/'current_native_raw.zip',c));case_results.append(v);(a.out/(c+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
  if a.include_previous:
   v=analyze(c+'_HISTORICAL_REPEAT',m,Archive(base/'previous_native_raw.zip',c));(a.out/(c+'_HISTORICAL_REPEAT.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
 csvrows=[]
 for c in sorted(case_results,key=lambda x:x['case']):
  u=c['updates'][-1] if c['updates'] else {};p=c['native_returned_point_metrics'] or {};contrast=u.get('source_contrast') or {}
  csvrows.append({'case':c['case'],'outcome':c['status'],'original_error_best5pct_m':p.get('best5pct_error_m'),'original_error_mean_m':p.get('mean_error_m'),'original_search_s':p.get('search_time_s'),'last_truth_legal':u.get('truth_legal'),'last_truth_rank':u.get('truth_strict_rank'),'last_truth_mass':u.get('truth_cell_mass'),'last_truth_in90':u.get('truth_in90pct_set'),'last_variance_m2':u.get('variance_m2'),'measurement_stops':c['measurement_stops'],'positive_events':c['positive_events'],'observed_events':c['observed_events'],'height_difference_m':c['source_sensor_height_difference_m'],'native_noise_stdev':c['native_noise_stdev'],'native_candidate_calls':c['native_candidate_calls'],'last_direct_Brier_best_minus_truth':contrast.get('mean_direct_stop_Brier_best_minus_truth')})
 with (a.out/'CASE_COMPARISON.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=csvrows[0]);w.writeheader();w.writerows(csvrows)
 qualified=[c for c in case_results if c['original_native_status'].get('native_goal_count',0)>0 and c['original_native_status'].get('preflight')=='PASS' and c['status']!='ENGINEERING_OR_DATA_INVALID' and c['clock_backwards']==0 and c['complete_source_updates']>0]
 summary={'status':'FULL20_COMPLETE_CASE_ANALYSIS' if len(qualified)==20 else 'PARTIAL_INCREMENTAL_CASE_ANALYSIS','cases_analyzed':len(case_results),'qualified_native_cases':len(qualified),'unqualified_cases':[c['case'] for c in case_results if c not in qualified],'missing_native_records':missing,'outcome_counts':{k:sum(c['status']==k for c in case_results) for k in sorted({c['status'] for c in case_results})},'cases':csvrows,
  'scientific_boundary':'Not20independent replicates; no retuning based on failures. Associations across official settings cannot uniquely attribute model error. Original native point definition, variance convergence and distance correctness remain distinct.'}
 (a.out/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in summary.items() if k!='cases'},ensure_ascii=False))
if __name__=='__main__':main()
