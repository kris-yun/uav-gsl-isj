from pathlib import Path
import csv,json,collections,argparse
import numpy as np
from cdr_grid import decode_grid
ap=argparse.ArgumentParser();ap.add_argument('--data',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);args=ap.parse_args();assert not args.out.exists();results=[];cache={}
index=json.loads((args.data/'CASE_INDEX.json').read_text());groups={g['group']:g for g in index['field_groups']}
for entry in index['cases']:
 c=entry['case'];root=args.data/entry['native_path'];first=next(p.parent for p in sorted((root/'runtime/updates').glob('*/COMPLETE.txt')));m=json.loads((first/'metadata.json').read_text());rows=list(csv.DictReader((first/'input.csv').open()));native=np.array([a['occupancy']=='1' for a in rows]).reshape(m['height'],m['width']);raw=None
 for line in (root/'runtime/raw_ros_cdr.jsonl').read_text().splitlines():
  a=json.loads(line)
  if a['topic']=='/PioneerP3DX/map':raw=bytes.fromhex(a['cdr_hex']);break
 assert raw is not None;fine_meta,fine=decode_grid(raw);ref=np.load(args.data/entry['support_reference_npz']);assert np.array_equal(fine,ref['fine']) and np.array_equal(native,ref['native_free']);scale=round(m['cell_size']/fine_meta['resolution']);h,w=native.shape;coarse=np.all(fine[:h*scale,:w*scale].reshape(h,scale,w,scale)==0,axis=(1,3));assert np.array_equal(coarse,ref['coarse_before_prune'])
 key=entry['group']
 if key not in cache:
  text=(args.data/groups[key]['grid_path']).read_text().splitlines();minimum=np.array([float(a) for a in text[0].split()[1:]]);dims=np.array([int(a) for a in text[2].split()[1:]]);cell=float(text[3].split()[1]);cells=np.array([[int(a) for a in line.split()] for line in text[4:] if line!=';'],np.int8).reshape(dims[2],dims[0],dims[1]);cache[key]=(minimum,dims,cell,cells)
 minimum,dims,cell,cells=cache[key];truth=np.array(entry['metadata']['source_xyz']);ijk=np.floor((truth-minimum)/cell).astype(int);assert np.all(ijk>=0) and np.all(ijk<dims) and cells[ijk[2],ijk[0],ijk[1]]==0;i=int((truth[0]-m['origin_x'])/m['cell_size']);j=int((truth[1]-m['origin_y'])/m['cell_size']);supported=bool(native[j,i]);fi=int((truth[0]-fine_meta['origin_xyz'][0])/fine_meta['resolution']);fj=int((truth[1]-fine_meta['origin_xyz'][1])/fine_meta['resolution']);reason='SUPPORTED' if supported else 'BLOCKED_FINE_SOURCE_PIXEL' if fine[fj,fi]!=0 else 'COARSENING_EXCLUSION' if not coarse[j,i] else 'CONNECTIVITY_EXCLUSION';results.append({'case':c,'source_3d_gas_free':True,'native_source_supported':supported,'exclusion_stage':reason,'new_raw_map_matches_frozen_geometry_reference':True})
assert len(results)==20
result={'status':'PASS_ALL20_ACTUAL_RAW_MAP_AND_PHYSICAL_SOURCE_GEOMETRY','counts':dict(collections.Counter(r['exclusion_stage'] for r in results)),'cases':results};args.out.write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'counts':result['counts']}))
