"""Minimal ROS2 CDR WindPosition response decoder; validated against ROS deserialization."""
import struct
import numpy as np
def decode_response(data):
 if data[:2]!=b'\x00\x01':raise ValueError('Expected little-endian ROS2 CDR encapsulation')
 position=4;vectors=[]
 for _ in range(3):
  position+=(-(position-4))%4
  n=struct.unpack_from('<I',data,position)[0];position+=4;position+=(-(position-4))%8
  if position+n*8>len(data):raise ValueError('Truncated WindPosition response')
  vectors.append(np.frombuffer(data,'<f8',n,position).copy());position+=n*8
 if position!=len(data):raise ValueError('Unexpected trailing CDR payload')
 if len({len(a) for a in vectors})!=1:raise ValueError('UVW dimensions differ')
 return np.column_stack(vectors)
