from pathlib import Path
import csv,json,bisect,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--data',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);args=ap.parse_args();assert not args.out.exists();rows=[]
index=json.loads((args.data/'CASE_INDEX.json').read_text())
for e in index['cases']:
 root=args.data/e['native_path'];table=list(csv.DictReader((args.data/e['frame_time_path']).open()));times=[float(a['physical_snapshot_time_s']) for a in table];trace=list(csv.DictReader((root/'runtime/physical_clock_trace.csv').open()));p=e['player'];initial=p['initial_iteration'];cyclic=p['allow_looping'];lo=p['loop_from_iteration'];hi=p['loop_to_iteration'];duration=times[initial+1]-times[initial];period=times[hi+1]-times[lo];errors=[];wraps=0;last=None
 for a in trace:
  elapsed=(int(a['receipt_ros_ns'])-int(a['anchor_ros_ns']))/1e9;target=times[initial]+elapsed if not cyclic or elapsed<duration else times[lo]+((elapsed-duration)%period);frame=min(len(times)-2,bisect.bisect_right(times,target)-1)
  if cyclic and elapsed>=duration:frame=min(hi,max(lo,frame))
  assert int(a['frame'])==frame,(e['case'],a,frame);assert abs(float(a['frame_internal_s'])-times[frame])<1e-7 and abs(float(a['next_frame_internal_s'])-times[frame+1])<1e-7;assert int(a['wind_index'])==int(table[frame]['wind_index_at_save']);error=abs(float(a['target_internal_s'])-target);assert error<1e-5;errors.append(error)
  if last is not None and frame<last:wraps+=1
  last=frame
 if cyclic:assert wraps>0
 rows.append({'case':e['case'],'trace_rows':len(trace),'physical_phase_wraps':wraps,'max_phase_error_s':max(errors),'status':'PASS_ACTUAL_FRAME_TIME_AND_WIND_BINDING'})
assert len(rows)==20
args.out.write_text(json.dumps({'status':'PASS_ALL20_ACTUAL_PHYSICAL_CLOCK_BINDINGS','cases':rows},indent=2));print(json.dumps({'status':'PASS_ALL20_ACTUAL_PHYSICAL_CLOCK_BINDINGS','cases':20}))
