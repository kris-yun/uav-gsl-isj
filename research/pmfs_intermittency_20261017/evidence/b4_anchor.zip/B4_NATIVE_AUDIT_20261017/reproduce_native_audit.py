"""Reproduce native B4 diagnostics in a NEW folder. Never starts ROS or a gas world."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json,os,hashlib
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();O=Path(a.out).resolve();O.mkdir(parents=True,exist_ok=False);(O/'OWNED_B4_OFFLINE_REVIEW.marker').write_text('Only offline replay of preserved native records.')
for n in ['analyze_native.py','mechanism_checks.py','inspect_stationary_queries.py','run_hit_experiment.py','replay_native_hit_history.py','verify_wind_input.py','native_readout.cpp','native_hit_experiment.cpp','native_hit_history.cpp']:shutil.copyfile(R/n,O/n)
shutil.copytree(R/'inputs',O/'inputs');ledger=[]
for n in ['analyze_native.py','mechanism_checks.py','inspect_stationary_queries.py','run_hit_experiment.py','replay_native_hit_history.py','verify_wind_input.py']:
 q=subprocess.run([sys.executable,str(O/n)],capture_output=True,text=True,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));ledger.append(dict(script=n,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr));(O/'EXECUTION.json').write_text(json.dumps(ledger,indent=2));assert q.returncode==0,ledger[-1]
import pandas as pd
x=pd.read_csv(O/'results/HISTORY_REPLAY_QA.csv');assert len(x)==36 and x.log_odds_max_abs_error.max()==0 and x.confidence_max_abs_error.max()==0
qa=dict(pass_all=True,original_native_episodes_analyzed=8,replayed_observation_windows=580,matched_source_epochs=36,matched_free_cell_states=int(x.cells.sum()),max_log_odds_error=0,max_confidence_error=0,new_ROS_episodes=0,new_worlds=0,main_innovation_established=False)
(O/'FINAL_QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2))
