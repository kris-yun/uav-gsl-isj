"""Recompute native-only B4 outcomes, support, probability and observation diagnostics."""
from pathlib import Path
import numpy as np,pandas as pd,json,subprocess,re,hashlib,datetime,math
R=Path(__file__).resolve().parent;I=R/'inputs';O=R/'results';O.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))
def read(p):return pd.read_csv(p,float_precision='round_trip')
def params(p):
 x=load(p);types={1:'bool_value',2:'integer_value',3:'double_value',4:'string_value'}
 return {k:v[types[v['type']]] for k,v in zip(x['names'],x['values']) if v['type'] in types}
def posterior_metrics(a,truth):
 q=a.source_probability.to_numpy();xy=a[['x_m','y_m']].to_numpy();cs=float(a.cell_size_m.iloc[0]);d=np.linalg.norm(xy-truth,axis=1)
 # Use the lower corner and a half-open physical cell, not rounded nearest-center truth ownership.
 ix=(xy[:,0]-cs/2<=truth[0])&(truth[0]<xy[:,0]+cs/2)&(xy[:,1]-cs/2<=truth[1])&(truth[1]<xy[:,1]+cs/2)
 assert ix.sum()==1,(truth,xy[ix]);j=np.where(ix)[0][0];p=float(q[j]);above=float(q[q>p].sum());mu=(q[:,None]*xy).sum(0)/q.sum();var=float(((xy-mu)**2*q[:,None]).sum())
 return dict(truth_probability=p,truth_strict_rank=int((q>p).sum()+1),truth_mass_above=above,truth_in_HPD90_with_cutoff_ties=above<.9,truth_in_HPD50_with_cutoff_ties=above<.5,mass_within_0p5m=float(q[d<=.5].sum()),mass_within_1m=float(q[d<=1].sum()),mean_error_m=float(np.linalg.norm(mu-truth)),variance_numpy_m2=var,entropy_nats=float(-(q[q>0]*np.log(q[q>0])).sum()),effective_cells=float(1/(q*q).sum()),truth_hit_probability=float(1/(1+np.exp(-a.hit_log_odds.iloc[j]))),truth_hit_confidence=float(a.hit_confidence.iloc[j]),map_cells=len(q),posterior_sum=float(q.sum()))
cmd=['g++','-std=c++17','-O2',str(R/'native_readout.cpp'),'-o',str(O/'native_readout')];c=subprocess.run(cmd,capture_output=True,text=True);assert c.returncode==0,c.stderr
summ=[];updates=[];stops=[];goals=[];ident=[];qa=[];paths=[];post=[]
allruns=[('EXT5',p) for p in sorted((I/'EXT5').glob('*B4*'))]+[('PC16',I/'PC16/runtime')]
for kind,p in allruns:
 name=p.name if kind=='EXT5' else 'PC16_audit_B4';par=params(p/'resolved_GSL_parameters.json');pp=read(p/'native_posterior_updates.csv');truth=np.array([par['ground_truth_x'],par['ground_truth_y']]);raw=np.loadtxt(p/'native_results.csv').reshape(-1);assert len(raw)==6
 cp=subprocess.run([str(O/'native_readout'),str(p/'native_posterior_updates.csv')],capture_output=True,text=True);assert cp.returncode==0; (O/(name+'_READOUT.csv')).write_text(cp.stdout)
 import io
 dec=pd.read_csv(io.StringIO(cp.stdout));last=dec.iloc[-1];a=pp[pp['update']==pp['update'].max()].copy();met=posterior_metrics(a,truth)
 err=float(np.linalg.norm(last[['top5_x','top5_y']].to_numpy(dtype=float)-truth));vare=float(abs(last.variance_m2-raw[5]));eerr=abs(err-raw[3]);meanerr=abs(float(np.linalg.norm(last[['mean_x','mean_y']].to_numpy(dtype=float)-truth))-raw[2]);assert eerr<1e-5,(name,eerr);assert vare<1e-5,(name,vare);assert meanerr<1e-5
 win=read(p/'native_window_consumption.csv');ws=win[win.status=='CONSUMED'];assert (ws.gas_count>0).all() and (ws.wind_count>0).all();threshold=par['th_gas_present'];hit=(ws.concentration_mean_ppm>threshold).to_numpy()
 if kind=='EXT5':
  meta=load(p/'CASE_META.json');ev=read(p/'native_events.csv');qap=load(I/'EXT5_RUN_META'/name/'TRIAL_QA.json');pose=read(p/'pose.csv');fh=read(p/'frame_history.csv');pathxy=pose[['x_m','y_m']].to_numpy();times=pose.sensor_ros_s.to_numpy();nd=np.linalg.norm(pathxy-truth,axis=1)
  qa.append(dict(id=name,raw_gas_hash=hashlib.sha256((p/'gas.csv').read_bytes()).hexdigest(),readout_error_abs=eerr,variance_error_abs=vare,mean_error_abs=meanerr,old_qa=qap['qa']))
  # Actual logged wall times pair sampling windows to received source-log goal events. Pose series is kept separate because it has a different clock.
  gg=[]
  for x in ev.itertuples():
   m=re.fullmatch(r'Sending goal \(([-0-9.]+), ([-0-9.]+)\)',str(x.message))
   if m:gg.append((float(x.native_log_wall_unix_s),float(m[1]),float(m[2])))
  gt=np.array([x[0] for x in gg]);gxy=np.array([x[1:] for x in gg]);duplicate=sum(np.linalg.norm(gxy[1:]-gxy[:-1],axis=1)<1e-7)
  for k,(t,x,y) in enumerate(gg):goals.append(dict(id=name,goal=k+1,wall_s=t,nominal_x=x,nominal_y=y,nominal_distance_to_truth=float(np.hypot(x-truth[0],y-truth[1]))))
  # Each sampling window is aligned to the last goal dispatch, not falsely to a nominal exact pose.
  for k,x in enumerate(ws.itertuples()):
   t=x.node_clock_ns*1e-9;g=int(np.searchsorted(gt,t,side='right'))
   stops.append(dict(id=name,event=x.event,goal_dispatch_ordinal=g,wall_end_s=t,mean_ppm=x.concentration_mean_ppm,hit=bool(hit[k]),gas_count=x.gas_count,wind_count=x.wind_count,wind_speed=x.wind_speed_mean,wind_direction=x.wind_direction_mean))
  pathlen=float(np.linalg.norm(np.diff(pathxy,axis=0),axis=1).sum());pathnear=float(nd.min());navab=int(qap['qa'].get('invalid_navigation_frame_messages',0));clock=read(p/'clock.csv');ros=clock.source_ros_s.to_numpy();reversal=int((np.diff(ros)<0).sum())
  paths.append(dict(id=name,actual_path_min_distance_m=pathnear,actual_path_length_m=pathlen,actual_path_samples=len(pose),near_truth_pose_samples=int((nd<=.5).sum()),pose_source_clock_backwards=int((np.diff(times)<0).sum()),note='Whole logged pose stream; no unrecorded exact host-to-pose time pairing asserted'))
  extra=dict(nominal_goals=len(gg),duplicate_consecutive_nominal_goals=int(duplicate),actual_path_min_distance_m=pathnear,actual_path_length_m=pathlen,clock_backwards=reversal,invalid_nav_frame_messages=navab,empty_observation_warnings=qap['qa'].get('empty_observation_warnings'),wind_service_errors=qap['qa'].get('wind_service_errors'),physical_frame_min=int(fh.frame.min()),physical_frame_max=int(fh.frame.max()),truth_used_online=False)
 else:
  meta=load(I/'PC16/case/CASE_META.json') if (I/'PC16/case/CASE_META.json').exists() else {};extra={}
 # Output-path differences are not scientific parameter differences.
 ident.append(dict(id=name,group=kind,parameters={k:v for k,v in par.items() if k not in ['resultsFile','navigationPathFile']}))
 for u,b in pp.groupby('update',sort=True):updates.append(dict(id=name,group=kind,update=int(u),**posterior_metrics(b,truth)))
 summ.append(dict(id=name,group=kind,native_declared=True,native_search_wall_s=float(raw[1]),native_top5_error_m=float(raw[3]),native_full_mean_error_m=float(raw[2]),native_variance_m2=float(raw[5]),cpp_top5_error_m=err,source_updates=int(pp['update'].nunique()),consumed_windows=len(ws),gas_threshold_ppm=threshold,positive_window_fraction=float(hit.mean()),mean_window_concentration_ppm=float(ws.concentration_mean_ppm.mean()),max_window_concentration_ppm=float(ws.concentration_mean_ppm.max()),wind_speed_mean=float(ws.wind_speed_mean.mean()),**met,**extra))
sd=pd.DataFrame(summ);ud=pd.DataFrame(updates);sd.to_csv(O/'NATIVE_B4_RUNS.csv',index=False);ud.to_csv(O/'NATIVE_B4_UPDATES.csv',index=False);pd.DataFrame(stops).to_csv(O/'WINDOWS_WITH_LAST_DISPATCH.csv',index=False);pd.DataFrame(goals).to_csv(O/'NOMINAL_GOALS.csv',index=False);pd.DataFrame(paths).to_csv(O/'PATH_DIAGNOSTICS.csv',index=False)
save('PARAMETER_IDENTITIES.json',ident);save('NUMERICAL_AND_OBSERVATION_QA.json',qa)
base=ident[0]['parameters'];differences=[dict(id=x['id'],different_observed_values={k:[base[k],x['parameters'][k]] for k in set(base)&set(x['parameters']) if base[k]!=x['parameters'][k]},missing_in_reference=sorted(set(x['parameters'])-set(base)),missing_in_this_dump=sorted(set(base)-set(x['parameters']))) for x in ident];save('PARAMETER_DIFFERENCES.json',differences);assert all(not x['different_observed_values'] for x in differences)
# Parameter dumps were captured at different initialization stages; missing dynamic declarations are not automatically value changes.
launch=[]
for name in sd[sd.group=='EXT5'].id:
 text=(I/'EXT5_RUN_META'/name/'N1_launch.py').read_text();normal=re.sub(r'P24X5_B4_WALL5_V2_R\d+(?:_T\d+)?','B4_RUN',text)
 launch.append(dict(id=name,normalized_sha256=hashlib.sha256(normal.encode()).hexdigest(),stop_and_measure_time_0p4_declared='{"stop_and_measure_time": 0.4}' in text,scale_25_declared='{"scale": 25}' in text))
save('LAUNCH_IDENTITY.json',launch);assert len(set(x['normalized_sha256'] for x in launch))==1,launch
ext=sd[sd.group=='EXT5'];save('SUMMARY.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualified_same_setting_native_repeats=len(ext),all_declared=bool(ext.native_declared.all()),native_error_min_m=float(ext.native_top5_error_m.min()),native_error_max_m=float(ext.native_top5_error_m.max()),native_error_mean_m=float(ext.native_top5_error_m.mean()),native_search_wall_mean_s=float(ext.native_search_wall_s.mean()),native_truth_HPD90_containment_count=int(ext.truth_in_HPD90_with_cutoff_ties.sum()),worst_error_id=str(ext.loc[ext.native_top5_error_m.idxmax(),'id']),all_observed_common_parameters_equal=True,all_launches_equal_after_run_path_normalization=True,new_ROS_episodes=0,new_worlds=0,scope='Existing native real closed loops; eight online repeats of one gas realization, not eight independent transport worlds. Error is continuous, no posthoc failure threshold introduced.'))
print(sd[['id','native_top5_error_m','native_variance_m2','truth_strict_rank','truth_in_HPD90_with_cutoff_ties','positive_window_fraction','source_updates','actual_path_min_distance_m']].to_string(index=False))
