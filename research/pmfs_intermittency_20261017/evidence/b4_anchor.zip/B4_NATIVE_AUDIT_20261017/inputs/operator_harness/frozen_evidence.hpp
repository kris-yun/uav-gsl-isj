#pragma once
#include "imperfect_inverse.hpp"
#include <cstdint>
namespace iip {
// Fast source weights are anchored once per captured physical-model epoch.
// This is an explicit surrogate operator, NOT a physical likelihood calibration.
class FrozenEvidence {
 std::vector<double> prior_,base_;std::vector<size_t> owner_;std::vector<Point> xy_;uint64_t epoch_=0,last_=0;
public:
 void reset(uint64_t epoch,const std::vector<double>&prior,const std::vector<Point>&xy,
            const std::vector<size_t>&owner,const std::vector<double>&base){
  moments(prior,xy);if(prior.size()!=owner.size()||base.empty())throw std::invalid_argument("anchor shape");
  for(auto i:owner)if(i>=base.size())throw std::invalid_argument("owner");for(double e:base)if(!std::isfinite(e))throw std::invalid_argument("score");
  epoch_=epoch;last_=0;prior_=prior;xy_=xy;owner_=owner;base_=base;
 }
 std::vector<double> project(uint64_t epoch,const std::vector<double>&score) const{
  if(prior_.empty()||epoch!=epoch_||score.size()!=base_.size())throw std::invalid_argument("stale/incompatible epoch");
  for(double e:score)if(!std::isfinite(e))throw std::invalid_argument("score");
  std::vector<double>v(prior_.size());double m=-INFINITY;
  for(size_t i=0;i<v.size();++i){v[i]=prior_[i]>0?std::log(prior_[i])+score[owner_[i]]-base_[owner_[i]]:-INFINITY;m=std::max(m,v[i]);}
  double z=0;for(double& a:v)z+=(a=std::exp(a-m));for(double&a:v)a/=z;return v;
 }
 // score is computed from the complete current measured map; never multiply this
 // full-map factor onto the previously projected distribution.
 std::vector<double> observe(uint64_t epoch,uint64_t serial,const std::vector<double>&score){
  if(serial<=last_)throw std::invalid_argument("duplicate observation serial");auto v=project(epoch,score);last_=serial;return v;
 }
 uint64_t epoch()const{return epoch_;}
};
}
