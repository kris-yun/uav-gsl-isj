
#include <gsl_server/Utils/Math.hpp>
#include <random>
namespace GSL::Utils {
static thread_local std::minstd_rand0 normal_engine;
static uint64_t uniform_calls=0;
uint64_t audit_uniform_position(){return uniform_calls;}
static thread_local std::mt19937 uniform_engine([](){const char* p=std::getenv("FORWARD_SEED");return p?uint32_t(std::stoul(p)):20261016u;}());
double lerp(double s,double e,double p){if(p<0||std::isnan(p))return s;return s+(e-s)*std::min(1.,p);}
double clamp(double v,double a,double b){return std::max(a,std::min(b,v));}
double remapRange(double v,double a,double b,double c,double d){return c+(v-a)*(d-c)/(b-a);}
double logOddsToProbability(double v){return 1.-1./(1.+std::exp(v));}
double randomFromGaussian(double m,double sd){static thread_local std::normal_distribution<double> dist(0.,1.);return m+sd*dist(normal_engine);}
double uniformRandom(double a,double b){++uniform_calls;return a+(b-a)*std::generate_canonical<double,53>(uniform_engine);}
void NormalizeDistribution(Grid<double> v){double sum=0;for(size_t i=0;i<v.data.size();++i)if(v.occupancy[i]==Occupancy::Free)sum+=v.data[i];if(!(sum>0))throw std::runtime_error("zero normalization");for(size_t i=0;i<v.data.size();++i)if(v.occupancy[i]==Occupancy::Free)v.data[i]/=sum;}
}

namespace GSL::Utils {
double evaluate1DGaussian(double d,double s){return exp(-.5*std::pow(d/s,2))/(s*sqrt(2*M_PI));}
double evaluate2DGaussian(const Vector2& p,const Vector2& s,float a){Vector2 v=vmath::rotate(p,-a);return exp(-.5*(std::pow(v.x/s.x,2)+std::pow(v.y/s.y,2)))/(2*M_PI*s.x*s.y);}
}
