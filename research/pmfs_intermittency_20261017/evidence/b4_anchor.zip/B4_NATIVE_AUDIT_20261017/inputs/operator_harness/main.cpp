#include <gsl_server/algorithms/PMFS/internal/Simulations.hpp>
#include <gsl_server/Utils/Math.hpp>
#include <DDA/DDA.h>
#include <chrono>
using namespace GSL;
std::ofstream captures; size_t ncap=0;GridMetadata* md=nullptr;
std::ofstream scores,rng; std::string audit_prefix;
namespace GSL::Utils {uint64_t audit_uniform_position();}
namespace GSL::PMFS_internal {
void record_begin(const SimulationSource& s){
 auto n=s.nqaNode;
 rng<<ncap+1<<','<<n->origin.x<<','<<n->origin.y<<','<<n->size.x<<','<<n->size.y<<','<<GSL::Utils::audit_uniform_position()<<'\n';
}
void record_gaussian_end(uint16_t index,const std::array<float,2500>&table){
 std::ofstream pos(audit_prefix+"_gaussian_positions.csv",std::ios::app);
 if(ncap==1)pos<<"candidate,gaussian_index_after\n";
 pos<<ncap<<','<<index<<'\n';
 if(ncap==1){std::ofstream f(audit_prefix+"_gaussian_table.csv");f<<"index,value\n"<<std::setprecision(9);for(size_t i=0;i<table.size();++i)f<<i<<','<<table[i]<<'\n';}
}
void record_score(const SimulationSource& s,double score){auto n=s.nqaNode;scores<<ncap<<','<<n->origin.x<<','<<n->origin.y<<','<<n->size.x<<','<<n->size.y<<','<<std::setprecision(17)<<score<<','<<score/(n->size.x*n->size.y)<<'\n';}

void record_capture(const SimulationSource& s,const std::vector<float>& hit,size_t steps,int warmup){
  ++ncap;auto n=s.nqaNode;
  for(size_t i=0;i<hit.size();++i){if(hit[i]==0)continue;auto ij=s.metadata.indices2D(i);captures<<ncap<<','<<n->origin.x<<','<<n->origin.y<<','<<n->size.x<<','<<n->size.y<<','<<ij.x<<','<<ij.y<<','<<std::setprecision(9)<<hit[i]<<','<<steps<<','<<warmup<<'\n';}
  // All-zero candidate marker ensures empty maps are not silently lost.
  if(std::all_of(hit.begin(),hit.end(),[](float x){return x==0;}))captures<<ncap<<','<<n->origin.x<<','<<n->origin.y<<','<<n->size.x<<','<<n->size.y<<",-1,-1,0,"<<steps<<','<<warmup<<'\n';
}
}
int main(int argc,char**argv){try{
 if(argc!=3)throw std::runtime_error("native_predictor INPUT.txt OUTPUT_PREFIX");
 std::ifstream in(argv[1]);GridMetadata meta;size_t H,W;double ox,oy,cs;int region,wi,rec;double dt,noise,D,refine;size_t range;
 in>>H>>W>>ox>>oy>>cs>>region>>wi>>rec>>dt>>noise>>D>>refine>>range;
 meta.height=H;meta.width=W;meta.origin={float(ox),float(oy)};meta.cellSize=float(cs);meta.scale=25;meta.numFreeCells=0;
 std::vector<Occupancy>occ(H*W,Occupancy::Obstacle);std::vector<PMFS_internal::HitProbability>hp(H*W);std::vector<Vector2>wind(H*W);std::vector<double>sp(H*W,0);
 for(size_t k=0;k<H*W;++k){int f;double l,c,u,v;in>>f>>l>>c>>u>>v;if(!in)throw std::runtime_error("truncated input");occ[k]=f?Occupancy::Free:Occupancy::Obstacle;hp[k].logOdds=l;hp[k].confidence=c;wind[k]={float(u),float(v)};meta.numFreeCells+=f;}
 PMFS_internal::SimulationSettings st{};st.maxRegionSize=region;st.maxWarmupIterations=wi;st.iterationsToRecord=rec;st.deltaTime=dt;st.noiseSTDev=noise;st.sourceDiscriminationPower=D;st.refineFraction=refine;
 VisibilityMap vis(W,H,range);std::vector<std::vector<uint8_t>>im(H,std::vector<uint8_t>(W));
 for(size_t r=0;r<H;++r)for(size_t c=0;c<W;++c){Vector2Int from{int(r),int(c)};size_t k=c+r*W;im[r][c]=occ[k]==Occupancy::Free;std::vector<Vector2Int>vv;if(im[r][c])for(int rr=std::max(0,int(r)-int(range));rr<=std::min(int(H)-1,int(r)+int(range));++rr)for(int cc=std::max(0,int(c)-int(range));cc<=std::min(int(W)-1,int(c)+int(range));++cc){Vector2Int to{rr,cc};if(occ[cc+rr*W]!=Occupancy::Free)continue;auto start=meta.indexToCoordinates(from);auto end=meta.indexToCoordinates(to);bool visible=(to==from);if(!visible){auto ray=DDA::_2D::castRay<Occupancy>(start,end-start,vmath::length(end-start),DDA::_2D::Map<Occupancy>(occ,meta.origin,meta.cellSize,{W,H}),[](const Occupancy&o){return o==Occupancy::Free;});visible=!ray.hitSomething;}if(visible)vv.push_back(to);}vis.emplace(from,vv);}
 PMFS_internal::Simulations sim(Grid<PMFS_internal::HitProbability>(hp,occ,meta),Grid<double>(sp,occ,meta),Grid<Vector2>(wind,occ,meta),st);
 sim.initializeMap(im);sim.visibilityMap=&vis;sim.varianceOfHitProb.assign(H*W,0.0);
 audit_prefix=argv[2];scores.open(audit_prefix+"_scores.csv");scores<<"candidate,source_row,source_col,rows,cols,native_raw_score,score_per_area_diagnostic\n";rng.open(audit_prefix+"_rng.csv");rng<<"candidate,source_row,source_col,rows,cols,uniform_calls_before\n";captures.open(std::string(argv[2])+"_predictions.csv");captures<<"candidate,source_row,source_col,rows,cols,row,col,hit,particle_moves,warmup_steps\n";
 auto t=std::chrono::steady_clock::now();sim.updateSourceProbability(refine);double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();captures.close();
 std::ofstream out(std::string(argv[2])+"_posterior.csv");out<<"row,col,x,y,p,interest\n";double mass=0;
 for(size_t i=0;i<sp.size();++i)if(occ[i]==Occupancy::Free){auto ij=meta.indices2D(i);auto xy=meta.indexToCoordinates(ij);out<<ij.x<<','<<ij.y<<','<<std::setprecision(17)<<xy.x<<','<<xy.y<<','<<sp[i]<<','<<sim.varianceOfHitProb[i]<<'\n';mass+=sp[i];}
 std::cout<<"{\"free_cells\":"<<meta.numFreeCells<<",\"coarse_leaves\":"<<sim.QTleaves.size()<<",\"simulations\":"<<ncap<<",\"mass\":"<<std::setprecision(17)<<mass<<",\"wall_seconds\":"<<wall<<",\"label\":\"NEW_SAFE_RNG_PREDICTIONS_NOT_HISTORICAL_RNG\"}\n";
 return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
