#pragma once
#include "frozen_evidence.hpp"
#include <functional>
namespace iip {
// Live caller supplies ONLY currently allowed model predictions and callbacks
// operating on a COPY of its real measured-map state. No simulator observations.
struct ActionPrediction {std::vector<double> hit;double travel_seconds=0;};
class LiveDecisionBridge {
 FrozenEvidence evidence_;std::vector<double>q_;std::vector<Point>xy_;uint64_t serial_=0,epoch_=0;
public:
 void anchor(uint64_t epoch,uint64_t consumed_serial,const std::vector<double>&q,
             const std::vector<Point>&xy,const std::vector<size_t>&owner,const std::vector<double>&base_scores){
  evidence_.reset(epoch,q,xy,owner,base_scores);q_=q;xy_=xy;serial_=consumed_serial;epoch_=epoch;
 }
 const std::vector<double>& infer()const{return q_;}
 void assimilate(uint64_t epoch,uint64_t consumed_serial,const std::vector<double>&full_current_scores){
  if(epoch!=epoch_||consumed_serial<=serial_)throw std::invalid_argument("stale or repeated actual observation");
  q_=evidence_.observe(epoch,consumed_serial,full_current_scores);serial_=consumed_serial;
 }
 Choice choose(uint64_t epoch,uint64_t consumed_serial,const std::vector<ActionPrediction>&a,
    const std::function<std::vector<double>(size_t,int)>&shadow_full_scores,
    double sample_seconds,double budget_seconds,bool top5,int objective){
  if(epoch!=epoch_||consumed_serial!=serial_)throw std::invalid_argument("planning on unassimilated observation epoch");
  std::vector<Evaluation>e;std::vector<double>travel;e.reserve(a.size());
  for(size_t i=0;i<a.size();++i){
   auto q0=evidence_.project(epoch,shadow_full_scores(i,0));auto q1=evidence_.project(epoch,shadow_full_scores(i,1));
   e.push_back(evaluate(q_,xy_,a[i].hit,q0,q1,top5));travel.push_back(a[i].travel_seconds);
  }
  return choose_next(e,travel,sample_seconds,budget_seconds,objective);
 }
};
}
