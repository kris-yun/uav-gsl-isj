#include <gsl_server/algorithms/PMFS/PMFSLib.hpp>
namespace angles { inline double normalize_angle(double a){double v=std::fmod(a+M_PI,2*M_PI);return v<=0?v+M_PI:v-M_PI;} inline double shortest_angular_distance(double a,double b){double v=std::fmod(b-a+M_PI,2*M_PI);return v<=0?v+M_PI:v-M_PI;} }
namespace GSL {
    void PMFSLib::estimateHitProbabilities(Grid<HitProbability>& hitProb, const VisibilityMap& visibilityMap,
                                           PMFS_internal::HitProbabilitySettings& settings, bool hit, double downwindDirection, double windSpeed,
                                           Vector2Int robotPosition)
    {
        // receiving propagation this step. Can still be modified by better estimations.
        HashSet openPropagationSet;
        // causing propagation this step. No longer modifyable
        HashSet activePropagationSet;
        // old news
        HashSet closedPropagationSet;

        int i = robotPosition.x, j = robotPosition.y;

        int oI = std::max(0, i - settings.localEstimationWindowSize);
        int fI = std::min((int)hitProb.metadata.height - 1, i + settings.localEstimationWindowSize);
        int oJ = std::max(0, j - settings.localEstimationWindowSize);
        int fJ = std::min((int)hitProb.metadata.width - 1, j + settings.localEstimationWindowSize);

        Vector2Int ij(i, j);

        double kernel_rotation_wind = -angles::normalize_angle(
            downwindDirection + M_PI / 2); // the orientation of the anemometer's frame of reference and the way it uses angles is weird, man
        HitProbKernel kernel = {
            kernel_rotation_wind,
            Vector2(settings.kernelSigma + settings.kernelStretchConstant * windSpeed,                             // semi-major ellipse axis
                    settings.kernelSigma / (1 + settings.kernelStretchConstant * windSpeed / settings.kernelSigma) // semi-minor axis
                    ),
            (hit ? 0.6f : 0.1f)};

        for (int r = oI; r <= fI; r++)
        {
            for (int c = oJ; c <= fJ; c++)
            {
                Vector2Int rc(r, c);
                if (visibilityMap.isVisible(ij, rc) != Visibility::Visible)
                    continue;

                // the neighbours that are between 1 and 3 cells away
                if (std::abs(c - j) >= 1 || std::abs(r - i) >= 1)
                {
                    if (hitProb.occupancyAt(r, c) == Occupancy::Free)
                        activePropagationSet.insert(rc);
                    else
                        closedPropagationSet.insert(rc);
                }
                // the ones that are right next to the robot
                else
                    closedPropagationSet.insert(rc);

                hitProb.dataAt(r, c).distanceFromRobot = vmath::length(Vector2(rc - ij));
                hitProb.dataAt(r, c).originalPropagationDirection = vmath::normalized(Vector2(rc - ij)); // TODO check this. Should be coordinates,
                                                                                                         // no?
                hitProb.dataAt(r, c).auxWeight = applyFalloffLogOdds(Vector2(rc - ij), kernel, settings);
            }
        }

        // propagate these short-range estimations to the entire environment using the navigation map
        // also calculate the distance field
        propagateProbabilities(hitProb, settings, openPropagationSet, closedPropagationSet, activePropagationSet, kernel);

        double logOddsPrior = std::log(settings.prior / (1 - settings.prior));
        for (size_t i = 0; i < hitProb.data.size(); i++)
        {
            if (hitProb.occupancy[i] != Occupancy::Free)
                continue;

            HitProbability& cell = hitProb.data[i];
            // BAYESIAN BINARY FILTER. this is the important part
            cell.logOdds += cell.auxWeight - logOddsPrior;
            GSL_ASSERT(!std::isnan(cell.logOdds));

            // confidence
            cell.omega += Utils::evaluate1DGaussian(cell.distanceFromRobot, settings.confidenceSigmaSpatial);
            double exponent = -cell.omega / std::pow(settings.confidenceMeasurementWeight, 2);
            cell.confidence = 1 - std::exp(exponent);
        }
    }

    double PMFSLib::propagateProbabilities(Grid<HitProbability>& hitProb, const PMFS_internal::HitProbabilitySettings& settings,
                                           HashSet& openPropagationSet, HashSet& closedPropagationSet, HashSet& activePropagationSet,
                                           const HitProbKernel& kernel)
    {
        double total = 0;

        auto calculateNewAuxWeight = [&openPropagationSet, &closedPropagationSet, &activePropagationSet, &kernel, &settings,
                                      &hitProb](int i, int j, Vector2Int previousCellIndices) {
            HitProbability& previousCell = hitProb.dataAt(previousCellIndices.x, previousCellIndices.y);
            HitProbability& currentCell = hitProb.dataAt(i, j);
            Vector2Int ij(i, j);

            float newDistance = previousCell.distanceFromRobot +
                                ((i == previousCellIndices.x || j == previousCellIndices.y) ? 1 : sqrt(2)); // distance of this new path to the cell
            float newWeight = applyFalloffLogOdds(previousCell.originalPropagationDirection * newDistance, kernel, settings);

            // if the cell can still receive propagation
            if (closedPropagationSet.find(ij) == closedPropagationSet.end() && activePropagationSet.find(ij) == activePropagationSet.end())
            {
                // if there already was a path to this cell
                if (openPropagationSet.find(ij) != openPropagationSet.end())
                {
                    // if the distance is the same, keep the best probability!
                    if (std::abs(newDistance - currentCell.distanceFromRobot) < 0.001 && newWeight > currentCell.auxWeight)
                    {
                        currentCell.auxWeight = newWeight;
                        currentCell.originalPropagationDirection = previousCell.originalPropagationDirection;
                    }
                    // else, keep the shortest path
                    else if (newDistance < currentCell.distanceFromRobot)
                    {
                        currentCell.auxWeight = newWeight;
                        currentCell.distanceFromRobot = newDistance;
                        currentCell.originalPropagationDirection = previousCell.originalPropagationDirection;
                    }
                }
                // if this is the first time we reach this cell
                else
                {
                    currentCell.auxWeight = newWeight;
                    currentCell.distanceFromRobot = newDistance;
                    currentCell.originalPropagationDirection = previousCell.originalPropagationDirection;
                    openPropagationSet.insert(ij);
                }
            }
        };

        while (!activePropagationSet.empty())
        {
            while (!activePropagationSet.empty())
            {
                Vector2Int p = *activePropagationSet.begin();

                if (hitProb.freeAt(p.x, p.y))
                    total += hitProb.dataAt(p.x, p.y).auxWeight;

                activePropagationSet.erase(activePropagationSet.begin());
                closedPropagationSet.insert(p);

                int oR = std::max(0, p.x - 1);
                int fR = std::min((int)hitProb.metadata.height - 1, p.x + 1);
                int oC = std::max(0, p.y - 1);
                int fC = std::min((int)hitProb.metadata.width - 1, p.y + 1);

                // 8-neighbour propagation
                for (int i = oR; i <= fR; i++)
                {
                    for (int j = oC; j <= fC; j++)
                    {
                        if (hitProb.freeAt(i, j))
                            calculateNewAuxWeight(i, j, p);
                    }
                }
            }

            activePropagationSet.clear();
            // the cells that were in the open set now are removed from it and can no longer receive propagation
            // therefore, the probabilities for these cells are now locked, and we can update the logodds
            for (const auto& par : openPropagationSet)
            {
                activePropagationSet.insert(par);
            }

            openPropagationSet.clear();
        }
        return total;
    }

    double PMFSLib::applyFalloffLogOdds(Vector2 originalVectorScaled, const HitProbKernel& kernel,
                                        const PMFS_internal::HitProbabilitySettings& settings)
    {
        double sampleGaussian = Utils::evaluate2DGaussian(originalVectorScaled, kernel.sigma, kernel.angle);
        double maxPossible = Utils::evaluate2DGaussian({0, 0}, kernel.sigma, kernel.angle);
        float prob = Utils::clamp(Utils::lerp(settings.prior, kernel.valueAt1, sampleGaussian / maxPossible), 0.001, 0.999);
        return std::log(prob / (1 - prob));
    }


}
