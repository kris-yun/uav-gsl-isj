#include "imperfect_inverse.hpp"
#include "frozen_evidence.hpp"
#include <iostream>
#include <functional>
int n=0;void check(bool x){++n;if(!x)throw std::runtime_error("assertion "+std::to_string(n));}
void close(double a,double b){check(std::abs(a-b)<1e-11);}
void bad(std::function<void()>f){bool ok=false;try{f();}catch(const std::exception&){ok=true;}check(ok);}
int main(){try{
 using namespace iip;std::vector<Point>x{{0,0},{2,0},{1,3}};std::vector<double>q{.2,.3,.5};auto m=moments(q,x);Point d{2,1};double direct=0;for(size_t i=0;i<q.size();++i)direct+=q[i]*(std::pow(x[i].x-d.x,2)+std::pow(x[i].y-d.y,2));close(direct,risk(q,x,d));close(risk(q,x,{m.mx,m.my}),m.variance);
 std::vector<double>h{.1,.9,.4},b0(3),b1(3);double p=0;for(int i=0;i<3;++i)p+=q[i]*h[i];for(int i=0;i<3;++i){b1[i]=q[i]*h[i]/p;b0[i]=q[i]*(1-h[i])/(1-p);}auto e=evaluate(q,x,h,b0,b1,false);close(e.bayes,e.cross);close(e.bayes,e.self);close(e.bias,0);check(e.cross<=m.variance+1e-12);
 auto f=evaluate(q,x,h,q,q,false);close(f.cross,m.variance);close(f.bayes+f.bias,f.cross);check(f.cross>=e.cross);auto c=choose_next({f,e},{1,2},2,10,2);check(c.action==1);check(choose_next({f,e},{1,2},2,2,2).action==-1);check(choose_next({e,e},{2,1},2,10,2).action==1);
 std::vector<Point>xp{x[2],x[0],x[1]};std::vector<double>qp{q[2],q[0],q[1]},hp{h[2],h[0],h[1]},p0{b0[2],b0[0],b0[1]},p1{b1[2],b1[0],b1[1]};auto g=evaluate(qp,xp,hp,p0,p1,false);close(g.cross,e.cross);
 bad([&]{moments({.2,.4},x);});bad([&]{moments({.2,-.2,1},x);});bad([&]{moments({.2,.2,.2},x);});bad([&]{evaluate(q,x,{NAN,.3,.2},q,q,0);});bad([&]{choose_next({e},{-1},2,10,0);});bad([&]{choose_next({e},{1},2,10,5);});
 FrozenEvidence fe;fe.reset(1,q,x,{0,1,2},{-1,-2,-3});auto z=fe.project(1,{-1,-2,-3});for(int i=0;i<3;++i)close(z[i],q[i]);auto z1=fe.observe(1,1,{-2,-2,-3});auto z2=fe.observe(1,2,{-2,-2,-3});for(int i=0;i<3;++i)close(z1[i],z2[i]);bad([&]{fe.observe(1,2,{-2,-2,-3});});bad([&]{fe.project(2,{-1,-2,-3});});fe.reset(3,{.5,.5,0},x,{0,1,2},{0,0,0});check(fe.project(3,{0,0,999})[2]==0);
 // Constructed imperfect-inverse example: an informative observation decoded in
 // reverse is worse for squared task loss than an uninformative safe estimator.
 std::vector<Point>xx{{0,0},{2,0}};std::vector<double>qq{.5,.5},hh{0,1};auto reversed=evaluate(qq,xx,hh,{0,1},{1,0},false);auto dull=evaluate(qq,xx,{.5,.5},qq,qq,false);close(reversed.bayes,0);close(reversed.cross,4);close(dull.cross,1);check(choose_next({reversed,dull},{1,1},1,10,0).action==0);check(choose_next({reversed,dull},{1,1},1,10,2).action==1);
 std::cout<<"PASS "<<n<<" assertions\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
