#pragma once
#include <gsl_server/algorithms/Common/Grid.hpp>
#include <gsl_server/algorithms/PMFS/internal/HitProbability.hpp>
#include <gsl_server/algorithms/PMFS/internal/HitProbKernel.hpp>
#include <gsl_server/algorithms/PMFS/internal/Settings.hpp>
#include <gsl_server/algorithms/PMFS/internal/VisibilityMap.hpp>
#include <gsl_server/Utils/Math.hpp>
namespace GSL {
class PMFSLib { using HashSet=std::unordered_set<Vector2Int>; using HitProbability=PMFS_internal::HitProbability;using HitProbKernel=PMFS_internal::HitProbKernel;
public:
static void estimateHitProbabilities(Grid<HitProbability>&,const VisibilityMap&,PMFS_internal::HitProbabilitySettings&,bool,double,double,Vector2Int);
static double propagateProbabilities(Grid<HitProbability>&,const PMFS_internal::HitProbabilitySettings&,HashSet&,HashSet&,HashSet&,const HitProbKernel&);
static double applyFalloffLogOdds(Vector2,const HitProbKernel&,const PMFS_internal::HitProbabilitySettings&);
}; }
