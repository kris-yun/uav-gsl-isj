#pragma once
#define ZoneScoped ((void)0)
#define ZoneScopedN(x) ((void)0)
