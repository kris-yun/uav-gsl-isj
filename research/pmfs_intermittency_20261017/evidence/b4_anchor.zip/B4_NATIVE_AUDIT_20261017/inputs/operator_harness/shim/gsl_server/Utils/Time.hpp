#pragma once
#include <chrono>
namespace GSL::Utils::Time {struct Stopwatch{std::chrono::steady_clock::time_point t=std::chrono::steady_clock::now();double ellapsed()const{return std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();}};}
