#pragma once
#define GSL_INFO(...) ((void)0)
#define GSL_INFO_COLOR(...) ((void)0)
#define GSL_TRACE(...) ((void)0)
#define GSL_ERROR(...) ((void)0)
#define GSL_ASSERT(x) do{if(!(x)) throw std::runtime_error("assertion: " #x);}while(0)
#define GSL_ASSERT_MSG(x,...) GSL_ASSERT(x)
