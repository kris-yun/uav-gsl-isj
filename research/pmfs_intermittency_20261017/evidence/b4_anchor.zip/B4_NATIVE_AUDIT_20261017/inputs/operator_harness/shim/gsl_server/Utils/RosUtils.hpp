#pragma once
namespace GSL::Utils {enum class valueColorMode{Linear,Logarithmic};}
