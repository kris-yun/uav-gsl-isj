#pragma once
#include <vector>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <stdexcept>
#include <limits>
namespace iip {
struct Point {double x,y;};
struct Moments{double mx=0,my=0,variance=0;};
inline Moments moments(const std::vector<double>&q,const std::vector<Point>&x){if(q.empty()||q.size()!=x.size())throw std::invalid_argument("shape");Moments m;double s=0;for(size_t i=0;i<q.size();++i){if(q[i]<0||!std::isfinite(q[i])||!std::isfinite(x[i].x)||!std::isfinite(x[i].y))throw std::invalid_argument("mass");s+=q[i];m.mx+=q[i]*x[i].x;m.my+=q[i]*x[i].y;}if(std::abs(s-1)>1e-8)throw std::invalid_argument("normalization");for(size_t i=0;i<q.size();++i)m.variance+=q[i]*(std::pow(x[i].x-m.mx,2)+std::pow(x[i].y-m.my,2));return m;}
inline Point estimate(const std::vector<double>&q,const std::vector<Point>&x,bool top5){auto m=moments(q,x);if(!top5)return {m.mx,m.my};std::vector<size_t> ids(q.size());std::iota(ids.begin(),ids.end(),0);std::stable_sort(ids.begin(),ids.end(),[&](size_t a,size_t b){return q[a]>q[b];});size_t n=std::max(size_t(1),size_t(std::ceil(.05*q.size())));Point p{0,0};double z=0;for(size_t j=0;j<n;++j){size_t i=ids[j];p.x+=q[i]*x[i].x;p.y+=q[i]*x[i].y;z+=q[i];}return {p.x/z,p.y/z};}
inline double risk(const std::vector<double>&truth_working,const std::vector<Point>&xy,Point d){auto m=moments(truth_working,xy);return m.variance+std::pow(d.x-m.mx,2)+std::pow(d.y-m.my,2);}
struct Evaluation {double bayes=0,self=0,cross=0,bias=0,predicted_hit=0;};
// The source distribution for expected loss and the approximate inverse output are
// deliberately separate. No true location or future physical observations enter.
inline Evaluation evaluate(const std::vector<double>&prior,const std::vector<Point>&xy,const std::vector<double>&hit,const std::vector<double>&inverse0,const std::vector<double>&inverse1,bool top5){
 moments(prior,xy);if(inverse0.size()!=prior.size()||inverse1.size()!=prior.size())throw std::invalid_argument("inverse shape");moments(inverse0,xy);moments(inverse1,xy);if(hit.size()!=prior.size())throw std::invalid_argument("hit shape");Evaluation e;
 for(size_t i=0;i<hit.size();++i){if(!std::isfinite(hit[i])||hit[i]<0||hit[i]>1)throw std::invalid_argument("hit support");e.predicted_hit+=prior[i]*hit[i];}
 for(int y=0;y<2;++y){std::vector<double>b(prior.size());double p=0;for(size_t i=0;i<b.size();++i){b[i]=prior[i]*(y?hit[i]:1-hit[i]);p+=b[i];}if(p==0)continue;for(auto&v:b)v/=p;const auto&a=y?inverse1:inverse0;auto db=estimate(b,xy,top5),da=estimate(a,xy,top5);e.bayes+=p*risk(b,xy,db);e.self+=p*risk(a,xy,da);e.cross+=p*risk(b,xy,da);auto mb=moments(b,xy);e.bias+=p*(std::pow(da.x-mb.mx,2)+std::pow(da.y-mb.my,2));}
 return e;
}
struct Choice{int action=-1;double value=std::numeric_limits<double>::infinity();};
inline Choice choose_next(const std::vector<Evaluation>&eval,const std::vector<double>&travel,double sample,double budget,int mode){if(mode<0||mode>2||!std::isfinite(sample)||sample<0||!std::isfinite(budget)||budget<0)throw std::invalid_argument("planner configuration");if(eval.size()!=travel.size())throw std::invalid_argument("action shape");Choice c;for(size_t a=0;a<eval.size();++a){if(std::isnan(travel[a])||travel[a]<0)throw std::invalid_argument("travel time");if(!std::isfinite(travel[a])||travel[a]+sample>budget)continue;double v=mode==0?eval[a].bayes:mode==1?eval[a].self:eval[a].cross;if(!std::isfinite(v)||v<0)throw std::invalid_argument("invalid risk");if(v<c.value-1e-12||(std::abs(v-c.value)<=1e-12&&(c.action<0||travel[a]<travel[c.action]-1e-12))){c.action=int(a);c.value=v;}}return c;}
}
