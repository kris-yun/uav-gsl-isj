#include <gsl_server/algorithms/PMFS/PMFSLib.hpp>
using namespace GSL;
int main(){
 std::cout<<std::setprecision(17)<<"hits_per_five,observations,empirical_hit_fraction,native_hit_probability,native_confidence,ordinary_beta_mean,native_factor_true_frequency,native_factor_zero_frequency,native_delta_hit,native_delta_miss\n";
 for(int nh:{1,2,3,4})for(int repeats:{1,5,20}){
  GridMetadata m;m.width=m.height=1;m.cellSize=.25;m.scale=25;m.origin={0,0};m.numFreeCells=1;
  std::vector<PMFS_internal::HitProbability>v(1);v[0].setProbability(.3);v[0].omega=0;v[0].confidence=0;v[0].auxWeight=-1;
  std::vector<Occupancy>occ(1,Occupancy::Free);Grid<PMFS_internal::HitProbability>g(v,occ,m);
  VisibilityMap vis(1,1,2);vis.emplace({0,0},std::vector<Vector2Int>{{0,0}});
  PMFS_internal::HitProbabilitySettings s{};s.prior=.3;s.kernelSigma=1.5;s.kernelStretchConstant=1.5;s.confidenceSigmaSpatial=1;s.confidenceMeasurementWeight=1;s.localEstimationWindowSize=2;
  PMFS_internal::HitProbKernel kh{0,Vector2(1.5f,1.5f),.6f},km{0,Vector2(1.5f,1.5f),.1f};
  double dh=PMFSLib::applyFalloffLogOdds({0,0},kh,s)-std::log(.3/.7),dm=PMFSLib::applyFalloffLogOdds({0,0},km,s)-std::log(.3/.7);
  for(int rep=0;rep<repeats;++rep)for(int k=0;k<5;++k)PMFSLib::estimateHitProbabilities(g,vis,s,k<nh,0,.5,{0,0});
  double p=Utils::logOddsToProbability(v[0].logOdds),f=nh/5.,alpha=v[0].confidence,D=.4;
  std::cout<<nh<<','<<5*repeats<<','<<f<<','<<p<<','<<alpha<<','<<(nh*repeats+.3)/(5*repeats+1)<<','<<1-D*alpha*std::abs(p-f)<<','<<1-D*alpha*std::abs(p)<<','<<dh<<','<<dm<<'\n';
 }
}
