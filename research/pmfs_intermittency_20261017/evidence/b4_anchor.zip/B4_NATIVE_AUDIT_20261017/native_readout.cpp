#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>
struct Cell {int r,c;float x,y;double p;};
int main(int argc,char**argv){
 if(argc!=2)return 2;
 std::ifstream in(argv[1]);std::string line;std::getline(in,line);std::map<int,std::vector<Cell>> groups;
 while(std::getline(in,line)){
  std::replace(line.begin(),line.end(),',',' ');std::istringstream s(line);int u;Cell c;double cs;
  if(s>>u>>c.r>>c.c>>c.x>>c.y>>cs>>c.p)groups[u].push_back(c);
 }
 std::cout<<std::setprecision(17)<<"update,mean_x,mean_y,top5_x,top5_y,variance_m2,sum_probability,top5_mass,top5_cells\n";
 for(auto&[u,v]:groups){
  std::sort(v.begin(),v.end(),[](const Cell&a,const Cell&b){return a.p>b.p;});
  double x=0,y=0,z=0,xx=0,yy=0,zz=0;int count=0;
  for(int i=0;i<(int)v.size();++i){x+=v[i].p*v[i].x;y+=v[i].p*v[i].y;z+=v[i].p;if(i<v.size()*.05){xx+=v[i].p*v[i].x;yy+=v[i].p*v[i].y;zz+=v[i].p;++count;}}
  float mx=x/z,my=y/z,tx=xx/zz,ty=yy/zz;double variance=0;
  for(const auto&c:v)variance+=(std::pow(double(c.x-mx),2)+std::pow(double(c.y-my),2))*c.p;
  std::cout<<u<<','<<mx<<','<<my<<','<<tx<<','<<ty<<','<<variance<<','<<z<<','<<zz<<','<<count<<'\n';
 }
}
