#include <gsl_server/algorithms/PMFS/PMFSLib.hpp>
#include <DDA/DDA.h>
using namespace GSL;
bool pathFree(GridMetadata metadata,const std::vector<Occupancy>&occupancy,const Vector2&origin,const Vector2&end){
 auto oi=metadata.coordinatesToIndex(origin),ei=metadata.coordinatesToIndex(end);
 if(occupancy[metadata.indexOf(oi)]!=Occupancy::Free||occupancy[metadata.indexOf(ei)]!=Occupancy::Free)return false;
 auto direction=end-origin;auto ray=DDA::_2D::castRay<Occupancy>(origin,direction,vmath::length(direction),DDA::_2D::Map<Occupancy>(occupancy,metadata.origin,metadata.cellSize,{metadata.width,metadata.height}),[](const Occupancy&o){return o==Occupancy::Free;});return !ray.hitSomething;
}
int main(int argc,char**argv){
 if(argc!=2)return 2;std::ifstream in(argv[1]);int H,W,nfree,nwin,range;double ox,oy,cs;in>>H>>W>>ox>>oy>>cs>>nfree>>nwin>>range;
 GridMetadata m;m.height=H;m.width=W;m.origin={float(ox),float(oy)};m.cellSize=cs;m.scale=25;m.numFreeCells=nfree;
 std::vector<PMFS_internal::HitProbability>state(H*W);std::vector<Occupancy>occ(H*W,Occupancy::Obstacle);std::vector<int>free;
 for(int k=0;k<nfree;++k){int r,c;in>>r>>c;occ[r*W+c]=Occupancy::Free;free.push_back(r*W+c);}
 for(auto&x:state){x.setProbability(.3);x.omega=0;x.confidence=0;x.auxWeight=-1;}
 VisibilityMap vis(W,H,range);
 for(int i=0;i<H;++i)for(int j=0;j<W;++j){Vector2Int ij{i,j};std::vector<Vector2Int>vv;if(occ[i*W+j]==Occupancy::Free)for(int r=std::max(0,i-range);r<=std::min(H-1,i+range);++r)for(int c=std::max(0,j-range);c<=std::min(W-1,j+range);++c){Vector2Int to{r,c};if(to==ij||pathFree(m,occ,m.indexToCoordinates(ij),m.indexToCoordinates(to)))vv.push_back(to);}vis.emplace(ij,vv);}
 PMFS_internal::HitProbabilitySettings s{};s.prior=.3;s.kernelSigma=1.5;s.kernelStretchConstant=1.5;s.confidenceSigmaSpatial=1;s.confidenceMeasurementWeight=1;s.localEstimationWindowSize=2;Grid<PMFS_internal::HitProbability>g(state,occ,m);
 std::cout<<std::setprecision(17)<<"window,update,row,col,log_odds,confidence,omega,aux_weight,distance_from_robot,original_direction_x,original_direction_y\n";
 for(int k=0;k<nwin;++k){int r,c,y,u;float speed,direction;in>>r>>c>>y>>speed>>direction>>u;if(!in)return 3;
  if(occ[r*W+c]!=Occupancy::Free)return 4;PMFSLib::estimateHitProbabilities(g,vis,s,y,direction,speed,{r,c});
  auto write=[&](int idx,int update){std::cout<<k+1<<','<<update<<','<<idx/W<<','<<idx%W<<','<<state[idx].logOdds<<','<<state[idx].confidence<<','<<state[idx].omega<<','<<state[idx].auxWeight<<','<<state[idx].distanceFromRobot<<','<<state[idx].originalPropagationDirection.x<<','<<state[idx].originalPropagationDirection.y<<'\n';};
  if(u)for(int idx:free)write(idx,u);
  else {auto probe=m.coordinatesToIndex(-3.2,-3.3);write(m.indexOf(probe),0);}
 }
}
