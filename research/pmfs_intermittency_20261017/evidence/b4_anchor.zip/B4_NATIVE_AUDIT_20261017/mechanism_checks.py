from pathlib import Path
import pandas as pd,numpy as np,json,re,hashlib,datetime,yaml
R=Path(__file__).resolve().parent;I=R/'inputs';O=R/'results'
def read(p):return pd.read_csv(p,float_precision='round_trip')
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2))
w=read(O/'WINDOWS_WITH_LAST_DISPATCH.csv');g=read(O/'NOMINAL_GOALS.csv')
agg=w.groupby(['id','goal_dispatch_ordinal']).agg(n=('hit','size'),hits=('hit','sum'),mean_ppm=('mean_ppm','mean'),wind_speed=('wind_speed','mean'),first_end_s=('wall_end_s','min'),last_end_s=('wall_end_s','max')).reset_index()
agg=agg.merge(g,left_on=['id','goal_dispatch_ordinal'],right_on=['id','goal'],how='left');agg.to_csv(O/'STOPS_NOMINAL_LOCATIONS.csv',index=False)
agg['mixed']=(agg.hits>0)&(agg.hits<agg.n);agg['near_source_nominal']=agg.nominal_distance_to_truth<=1
mix=[]
for n,a in agg.groupby('id'):
 mix.append(dict(id=n,stops=len(a),mixed_stops=int(a.mixed.sum()),nominal_near_source_stops=int(a.near_source_nominal.sum()),mixed_nominal_near_source_stops=int((a.mixed&a.near_source_nominal).sum()),scope='Posthoc descriptive stop categories; nominal target geometry, not exact sensor coordinates.'))
pd.DataFrame(mix).to_csv(O/'INTERMITTENT_CONTACT_DESCRIPTIVE.csv',index=False)
nav=[];source_epochs=[];wind=[];ident=[];stage=[]
for folder in sorted((I/'EXT5').glob('*B4*')):
 name=folder.name;pp=read(folder/'native_posterior_updates.csv');events=read(folder/'native_events.csv');runtime=I/'EXT5_RUNTIME'/name
 text=(runtime/'launch.log').read_text(errors='replace');plain=re.sub(r'\x1b\[[0-9;]*m','',text);lines=plain.splitlines();request_time=float(events[events.message=='Request received: PMFS'].iloc[0].native_log_wall_unix_s);declaration_time=float(events[events.message.fillna('').str.startswith('RESULT IS:')].iloc[-1].native_log_wall_unix_s)
 def log_entries(needle):
  result=[]
  for line in lines:
   if needle not in line:continue
   m=re.search(r'\[(\d{10}\.\d+)\]',line)
   if m and float(m[1])>=request_time:result.append(dict(wall_s=float(m[1]),line=line))
  return result
 success=log_entries('Goal succeeded');abort=[x for x in log_entries('Aborting handle.') if 'bt_navigator' in x['line']];recover=log_entries('Failed to make progress');tf=[x for x in log_entries('lookupTransform') if '[ERROR]' in x['line']];empty=log_entries('No gas measurements');service=log_entries('service call failed')
 for a in agg[agg.id==name].itertuples():
  if a.goal_dispatch_ordinal==0:continue
  dispatched=float(a.wall_s);ok=[x for x in success if dispatched<=x['wall_s']<=a.first_end_s]
  nav.append(dict(id=name,goal=int(a.goal_dispatch_ordinal),samples=int(a.n),goal_succeeded_before_first_sample=bool(ok),nominal_distance_to_truth=a.nominal_distance_to_truth,failed_progress_recovery_events_before_sample=sum(dispatched<=x['wall_s']<=a.first_end_s for x in recover),BT_terminal_abort_before_sample=sum(dispatched<=x['wall_s']<=a.first_end_s for x in abort)))
 stage.append(dict(id=name,request_host_wall_s=request_time,declaration_host_wall_s=declaration_time,post_request_TF_errors=len(tf),post_request_empty_warnings=len(empty),post_request_service_errors=len(service),BT_goal_successes=len(success),BT_aborts_before_declaration=sum(x['wall_s']<=declaration_time for x in abort),BT_aborts_after_declaration=sum(x['wall_s']>declaration_time for x in abort),controller_failed_progress_recoveries=len(recover),evidence_lines={'BT_aborts':abort,'recoveries':recover,'TF_errors':tf}))
 times=events[events.message.fillna('').str.startswith('Time ellapsed in simulation')].native_log_wall_unix_s.to_numpy();starttimes=events[events.message=='Started simulations. Might take a while!'].native_log_wall_unix_s.to_numpy();assert len(times)==pp['update'].nunique()
 for u,t,ts in zip(sorted(pp['update'].unique()),times,starttimes):
  a=pp[pp['update']==u];q=a.source_probability.to_numpy();xy=a[['x_m','y_m']].to_numpy();j=int(np.argmax(q));mean=(q[:,None]*xy).sum(0);tr=np.array([-3.2,-3.3]);cs=.25;idx=np.flatnonzero((xy[:,0]-cs/2<=tr[0])&(tr[0]<xy[:,0]+cs/2)&(xy[:,1]-cs/2<=tr[1])&(tr[1]<xy[:,1]+cs/2))[0]
  source_epochs.append(dict(id=name,update=int(u),simulation_start_wall_s=float(ts),simulation_finished_wall_s=float(t),mode_x=float(xy[j,0]),mode_y=float(xy[j,1]),mode_mass=float(q[j]),mean_x=float(mean[0]),mean_y=float(mean[1]),truth_wind_u=float(a.estimated_wind_u.iloc[idx]),truth_wind_v=float(a.estimated_wind_v.iloc[idx]),truth_hit_confidence=float(a.hit_confidence.iloc[idx]),truth_hit_log_odds=float(a.hit_log_odds.iloc[idx]),consumed_windows_before_simulation=int((w[(w.id==name)].wall_end_s<ts).sum())))
 # Same protected binary for every repeat is audited from the recorded per-run identity.
 ident.append(dict(id=name,identity=json.loads((runtime/'NATIVE_EXECUTABLE_IDENTITY.json').read_text()),clock_preflight=json.loads((runtime/'CLOCK_SENSOR_RATE_PREFLIGHT.json').read_text())))
pd.DataFrame(nav).to_csv(O/'NAVIGATION_TO_SAMPLE_QA.csv',index=False);pd.DataFrame(source_epochs).to_csv(O/'SOURCE_EPOCH_TIMELINE.csv',index=False);save('RUNTIME_ERROR_AND_RECOVERY_AUDIT.json',stage);save('BINARY_AND_CLOCK_IDENTITIES.json',ident)
assert all(x['goal_succeeded_before_first_sample'] for x in nav),[x for x in nav if not x['goal_succeeded_before_first_sample']]
# Audit core files directly against the archived official copy, rather than attributing added-planner behavior to native PMFS.
src=I/'historical_source/NR16';core=[]
for f in ['PMFSLib.cpp','MovingStatePMFS.cpp','PMFS_utils.cpp']:
 p=src/'evidence/official/gsl_server/src/server/algorithms/PMFS'/f;q=src/'actual_h24_v2/gsl_server/src/server/algorithms/PMFS'/f
 assert p.read_bytes()==q.read_bytes();core.append(dict(file=f,official_equals_actual=True,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
save('AUTHOR_CORE_PARITY.json',core)
# The older horizon record is a different computational and input profile, not a matched native failure control.
old=I/'current_native_raw/B4/runtime';oldpar=yaml.safe_load((old/'resolved_GSL_parameters.yaml').read_text());oldpar=next(iter(oldpar.values()))['ros__parameters'];oldplayer=yaml.safe_load((old/'resolved_player_parameters.yaml').read_text());oldplayer=next(iter(oldplayer.values()))['ros__parameters']
new=json.loads(next((I/'EXT5').glob('*B4*')).joinpath('CASE_META.json').read_text())
save('OLD_CENSOR_NOT_MATCHED_CONTROL.json',dict(old_resolved_subset={k:oldpar.get(k) for k in ['convergence_thr','use_sim_time','maxSearchTime','useWindGroundTruth','distanceWeight','blurSigmaX','minWarmupIterations']},old_player_subset={k:oldplayer.get(k) for k in ['initial_iteration','player_freq','allow_looping','use_sim_time','simulation_data_0']},current_profile=dict(convergence_thr=1.0,use_sim_time=False,maxSearchTime=1000000,useWindGroundTruth=False,source='2024-07-19 historical source, unchanged measurement/planning formulas',player=new['player']),conclusion='Different wind access, clocks, stopping budget and implementation parameters; older horizon censoring cannot identify a physical PMFS failure condition or be pooled as a matched counterexample.'))
print('NAVIGATION',len(nav),'all success before sampling',all(x['goal_succeeded_before_first_sample'] for x in nav));print(agg[agg.id.str.contains('R05|R06')][['id','goal_dispatch_ordinal','hits','mean_ppm','nominal_distance_to_truth']].to_string(index=False));print(pd.DataFrame([{k:v for k,v in x.items() if k!='evidence_lines'} for x in stage]).to_string(index=False))
