"""An exact archived native-operator experiment, not a new physical-world run."""
from pathlib import Path
import shutil,re,json,hashlib,subprocess,datetime
import pandas as pd,numpy as np
R=Path(__file__).resolve().parent;V=R/'inputs/operator_harness';O=R/'results'
if not V.exists():
 src=R.parent/'IA17_REVIEW/TR8_INFERENCE_AWARE_20261017/code/native_predictor'
 shutil.copytree(src,V,ignore=shutil.ignore_patterns('build','__pycache__'))
def func(text,signature):
 start=text.index(signature);i=text.index('{',start);depth=1;j=i+1
 while depth:
  if text[j]=='{':depth+=1
  if text[j]=='}':depth-=1
  j+=1
 return re.sub(r'\s+','',text[start:j])
native=(R/'inputs/historical_source/NR16/evidence/official/gsl_server/src/server/algorithms/PMFS/PMFSLib.cpp').read_text()
actual=(R/'inputs/historical_source/NR16/actual_h24_v2/gsl_server/src/server/algorithms/PMFS/PMFSLib.cpp').read_text();harness=(V/'native_observer.cpp').read_text();parity=[]
for sig in ['void PMFSLib::estimateHitProbabilities','double PMFSLib::propagateProbabilities','double PMFSLib::applyFalloffLogOdds']:
 a,b,c=func(native,sig),func(actual,sig),func(harness,sig);assert a==b==c,sig;parity.append(dict(function=sig,official_actual_harness_equal=True,normalized_body_sha256=hashlib.sha256(a.encode()).hexdigest()))
command=['g++','-std=c++20','-O2','-DOMIT_FMT=1','-include',str(V/'prelude.hpp'),'-I'+str(V/'shim'),'-I'+str(V/'upstream/include'),'-I'+str(V/'dda'),str(R/'native_hit_experiment.cpp'),str(V/'native_observer.cpp'),str(V/'math_control.cpp'),'-o',str(O/'native_hit_experiment')]
ledger=[]
for cmd in [command,[str(O/'native_hit_experiment')]]:
 p=subprocess.run(cmd,capture_output=True,text=True);ledger.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr
(O/'NATIVE_HIT_OPERATOR_EXPERIMENT.csv').write_text(ledger[-1]['stdout']);(O/'HIT_OPERATOR_EXECUTION.json').write_text(json.dumps(ledger,indent=2));(O/'HIT_FUNCTION_PARITY.json').write_text(json.dumps(parity,indent=2))
x=pd.read_csv(O/'NATIVE_HIT_OPERATOR_EXPERIMENT.csv');logit=lambda p:np.log(p/(1-p));N=x.observations.to_numpy();f=x.empirical_hit_fraction.to_numpy()
# At the receptor cell, applyFalloffLogOdds has peak values float(.6) and float(.1), exactly as archived.
a=float(x.native_delta_hit.iloc[0]);b=float(x.native_delta_miss.iloc[0]);l=logit(.3)+N*(f*a+(1-f)*b);expected=np.exp(-np.logaddexp(0,-l));error=float(np.max(abs(expected-x.native_hit_probability)))
assert error<1e-12,error
(O/'HIT_OPERATOR_QA.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exact_native_operator_called=True,functions_verified=3,rows=len(x),analytic_max_error=error,critical_fraction=float(-b/(a-b)),new_ROS_episodes=0,new_worlds=0,scope='One-cell operator counterexample under periodic intermittent contacts, not a new measured B4 run or proof that this alone caused R05.'),indent=2))
print(x.to_string(index=False));print('analytic max error',error,'critical fraction',-b/(a-b))
