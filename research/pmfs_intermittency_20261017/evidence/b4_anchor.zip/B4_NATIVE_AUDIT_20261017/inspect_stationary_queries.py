"""Identify measured-position plateaus in original gas requests, without concentration matching."""
from pathlib import Path
import json,numpy as np,pandas as pd
R=Path(__file__).resolve().parent;I=R/'inputs';O=R/'results';rows=[]
for folder in sorted((I/'EXT5_RUNTIME').glob('*B4*')):
 points=[]
 with (folder/'service_queries.jsonl').open() as f:
  for line in f:
   q=json.loads(line)
   if q['kind']=='GasPosition' and len(q['x'])==1:points.append((q['request_ns']*1e-9,q['x'][0],q['y'][0],q['z'][0]))
 points=np.array(points);start=0;ordinal=0
 for k in range(1,len(points)+1):
  if k==len(points) or np.linalg.norm(points[k,1:3]-points[start,1:3])>1e-5:
   a=points[start:k]
   if len(a)>=15:
    ordinal+=1;x,y,z=a[:,1:].mean(0);rows.append(dict(id=folder.name,plateau=ordinal,query_count=len(a),first_request_ros_s=a[0,0],last_request_ros_s=a[-1,0],x=x,y=y,z=z,source_distance_m=float(np.hypot(x+3.2,y+3.3))))
   start=k
out=pd.DataFrame(rows);out.to_csv(O/'ACTUAL_STATIONARY_GAS_QUERY_PLATEAUS.csv',index=False)
stops=pd.read_csv(O/'STOPS_NOMINAL_LOCATIONS.csv');mapped=[];qa=[]
for name,group in out.groupby('id',sort=False):
 merged=[]
 for item in group.to_dict('records'):
  if merged and np.hypot(item['x']-merged[-1]['x'],item['y']-merged[-1]['y'])<.005:
   old=merged[-1];n=old['query_count']+item['query_count'];old['x']=(old['x']*old['query_count']+item['x']*item['query_count'])/n;old['y']=(old['y']*old['query_count']+item['y']*item['query_count'])/n;old['query_count']=n;old['last_request_ros_s']=item['last_request_ros_s']
  else:merged.append(item.copy())
 target=stops[stops.id==name].sort_values('goal_dispatch_ordinal').to_dict('records');qa.append(dict(id=name,merged_stationary_segments=len(merged),native_sampling_stops=len(target),same_count=len(merged)==len(target)))
 assert len(merged)==len(target),qa[-1]
 pp=pd.read_csv(I/'EXT5'/name/'native_posterior_updates.csv');cs=float(pp.cell_size_m.iloc[0]);a=pp.iloc[0];ox=a.x_m-(a.col+.5)*cs;oy=a.y_m-(a.row+.5)*cs;truthrow=int(np.floor((-3.3-oy)/cs));truthcol=int(np.floor((-3.2-ox)/cs))
 for actual,nominal in zip(merged,target):
  goal=int(nominal['goal_dispatch_ordinal'])
  if goal:
   # Native log rounds goals to two decimals. Recover the uniquely matching source-grid center before testing Nav2 tolerance.
   xy=pp[['x_m','y_m']].drop_duplicates().to_numpy();di=np.linalg.norm(xy-np.array([nominal['nominal_x'],nominal['nominal_y']]),axis=1);j=int(di.argmin());assert di[j]<.008;tx,ty=xy[j];delta=float(np.hypot(actual['x']-tx,actual['y']-ty))
  else:delta=0.
  assert delta<=.2501,(name,goal,delta)
  row=int(np.floor((actual['y']-oy)/cs));col=int(np.floor((actual['x']-ox)/cs));mapped.append(dict(id=name,goal=goal,actual_x=actual['x'],actual_y=actual['y'],actual_z=actual['z'],actual_source_distance_m=float(np.hypot(actual['x']+3.2,actual['y']+3.3)),source_grid_cell_sampled=(row==truthrow and col==truthcol),row=row,col=col,gas_query_count=actual['query_count'],first_request_ros_s=actual['first_request_ros_s'],last_request_ros_s=actual['last_request_ros_s'],nominal_position_error_m=delta,windows=int(nominal['n']),hits=int(nominal['hits']),mean_ppm=nominal['mean_ppm'],binding='Chronological unique stationary gas-request segment plus goal geometry; no concentration-value matching; not a recovered per-window cross-clock receipt.'))
md=pd.DataFrame(mapped);md.to_csv(O/'ACTUAL_STOP_GEOMETRY_DIAGNOSTIC.csv',index=False);(O/'STATIONARY_BINDING_QA.json').write_text(json.dumps(qa,indent=2));print(md[md.id.str.contains('R05|R06')][['id','goal','actual_x','actual_y','actual_source_distance_m','source_grid_cell_sampled','windows','hits','mean_ppm']].to_string(index=False))
