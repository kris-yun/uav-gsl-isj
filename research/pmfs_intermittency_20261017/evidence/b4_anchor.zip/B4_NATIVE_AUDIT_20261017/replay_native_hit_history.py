"""Test recovered stationary input cells against all saved native hit-map updates."""
from pathlib import Path
import pandas as pd,numpy as np,json,subprocess
R=Path(__file__).resolve().parent;V=R/'inputs/operator_harness';O=R/'results';D=O/'history_replay';D.mkdir(exist_ok=True)
command=['g++','-std=c++20','-O2','-DOMIT_FMT=1','-include',str(V/'prelude.hpp'),'-I'+str(V/'shim'),'-I'+str(V/'upstream/include'),'-I'+str(V/'dda'),str(R/'native_hit_history.cpp'),str(V/'native_observer.cpp'),str(V/'math_control.cpp'),'-o',str(D/'native_hit_history')]
p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stderr
positions=pd.read_csv(O/'ACTUAL_STOP_GEOMETRY_DIAGNOSTIC.csv');windows=pd.read_csv(O/'WINDOWS_WITH_LAST_DISPATCH.csv');epoch=pd.read_csv(O/'SOURCE_EPOCH_TIMELINE.csv');qa=[];traces=[];states=[]
for name,a in positions.groupby('id',sort=False):
 folder=R/'inputs/EXT5'/name;pp=pd.read_csv(folder/'native_posterior_updates.csv',float_precision='round_trip');first=pp[pp['update']==pp['update'].min()];nav=json.loads((folder/'navigation_map.json').read_text());H=nav['height']//25;W=nav['width']//25;cs=float(first.cell_size_m.iloc[0]);ox=nav['origin']['x'];oy=nav['origin']['y'];ww=windows[windows.id==name].sort_values('event');steps=epoch[epoch.id==name].set_index('consumed_windows_before_simulation')['update'].to_dict();geo=a.set_index('goal');lines=[f'{H} {W} {ox:.17g} {oy:.17g} {cs:.17g} {len(first)} {len(ww)} 5']+[f'{int(r)} {int(c)}' for r,c in first[['row','col']].to_numpy()]
 for k,w in enumerate(ww.itertuples(),1):
  pos=geo.loc[w.goal_dispatch_ordinal];lines.append(f'{int(pos.row)} {int(pos.col)} {int(w.hit)} {w.wind_speed:.17g} {w.wind_direction:.17g} {int(steps.get(k,0))}')
 inp=D/(name+'.txt');inp.write_text('\n'.join(lines)+'\n');p=subprocess.run([str(D/'native_hit_history'),str(inp)],capture_output=True,text=True);assert p.returncode==0,(name,p.stderr);out=D/(name+'.csv');out.write_text(p.stdout);replay=pd.read_csv(out,float_precision='round_trip');joint=pp.merge(replay,on=['update','row','col']);assert len(joint)==len(pp)
 joint['id']=name;states.append(joint)
 for u,b in joint.groupby('update'):
  qa.append(dict(id=name,update=int(u),cells=len(b),log_odds_max_abs_error=float(abs(b.hit_log_odds-b.log_odds).max()),confidence_max_abs_error=float(abs(b.hit_confidence-b.confidence).max()),truth_log_odds_recorded=float(b[(abs(b.x_m+3.175)<1e-4)&(abs(b.y_m+3.255)<1e-4)].hit_log_odds.iloc[0]),truth_log_odds_replayed=float(b[(abs(b.x_m+3.175)<1e-4)&(abs(b.y_m+3.255)<1e-4)].log_odds.iloc[0])))
 probe=replay[(replay.row==18)&(replay.col==17)].sort_values('window').copy();assert len(probe)==len(ww)
 probe['id']=name;probe['goal']=ww.goal_dispatch_ordinal.to_numpy();probe['hit']=ww.hit.to_numpy();probe['mean_ppm']=ww.mean_ppm.to_numpy();probe['delta_log_odds']=np.diff(np.r_[np.log(.3/.7),probe.log_odds]);probe['delta_omega']=np.diff(np.r_[0.,probe.omega]);probe['hit_probability']=np.exp(-np.logaddexp(0,-probe.log_odds));traces.append(probe)
table=pd.DataFrame(qa);table.to_csv(O/'HISTORY_REPLAY_QA.csv',index=False);pd.concat(states).to_csv(O/'NATIVE_RECONSTRUCTED_JOINT_FIELDS.csv',index=False);trace=pd.concat(traces);trace.to_csv(O/'TRUTH_CELL_PER_WINDOW_NATIVE_REPLAY.csv',index=False);contributions=trace.groupby(['id','goal']).agg(delta_log_odds=('delta_log_odds','sum'),delta_omega=('delta_omega','sum'),final_probability=('hit_probability','last'),final_confidence=('confidence','last'),hits=('hit','sum'),windows=('hit','size')).reset_index();contributions.to_csv(O/'TRUTH_CELL_NATIVE_CONTRIBUTIONS_BY_STOP.csv',index=False)
assert float(table.log_odds_max_abs_error.max())==0 and float(table.confidence_max_abs_error.max())==0
print(table.to_string(index=False));print(contributions[contributions.id.str.contains('R05')].to_string(index=False));print('These are history reconstruction diagnostics; no new actions, observations or task gains.')
