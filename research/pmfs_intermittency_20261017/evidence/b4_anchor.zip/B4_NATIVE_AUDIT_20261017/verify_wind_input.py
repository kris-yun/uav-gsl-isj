"""Decode existing ROS2 CDR without ROS; check raw/adapted wind and stationary GMRF frame conversion."""
from pathlib import Path
import json,gzip,struct,math,csv
R=Path(__file__).resolve().parent;I=R/'inputs';O=R/'results'
def wrap(x):return math.atan2(math.sin(x),math.cos(x))
def decode(b):
 assert b[:2]==b'\x00\x01';offset=4
 def field(fmt):
  nonlocal offset
  size=struct.calcsize(fmt);offset+=(-offset)%min(size,4);x=struct.unpack_from('<'+fmt,b,offset)[0];offset+=size;return x
 def string():
  nonlocal offset
  n=field('I');x=b[offset:offset+n-1].decode();offset+=n;return x
 sec=field('i');ns=field('I');frame=string();label=string();speed=field('f');direction=field('f');assert offset==len(b)
 return dict(stamp=sec*1000000000+ns,frame=frame,label=label,speed=speed,direction=direction)
out=[]
for folder in sorted((I/'EXT5_RUNTIME').glob('*B4*')):
 raw={};adapt={}
 with gzip.open(folder/'raw_ros_cdr.jsonl.gz','rt') as f:
  for line in f:
   x=json.loads(line)
   if x['topic'] not in ['/PioneerP3DX/Anemometer/WindSensor_reading','/native20/wind_to']:continue
   m=decode(bytes.fromhex(x['cdr_hex']));(raw if x['topic'].endswith('WindSensor_reading') else adapt).setdefault(m['stamp'],[]).append(m)
 assert set(raw)==set(adapt);count=0;angle=0
 for stamp,items in raw.items():
  assert len(items)==len(adapt[stamp])
  for a,b in zip(items,adapt[stamp]):
   assert all(a[k]==b[k] for k in ['stamp','frame','label','speed'])
   expected=struct.unpack('<f',struct.pack('<f',wrap(a['direction']+math.pi)))[0];angle=max(angle,abs(wrap(b['direction']-expected)));count+=1
 assert angle==0
 goal=json.loads((I/'EXT5_RUN_META'/folder.name/'RUN_RESULT.json').read_text())['goal_invocation_ROS_ns'];errors=[];speeds=[]
 for x in csv.DictReader((I/'EXT5'/folder.name/'GMRF_consumed.csv').open()):
  stamp=int(x['message_stamp_ns'])
  if stamp>=goal or int(x['receipt_ros_ns'])>=goal or stamp not in raw:continue
  # Recorded initial yaw=1, static anemometer roll=pi. The historical GMRF's pi literal is 3.14159.
  candidates=raw[stamp];a=min(candidates,key=lambda m:abs(float(x['speed'])-m['speed'])+abs(wrap(float(x['downwind_map_rad'])-wrap(1-m['direction']+3.14159))))
  expected=wrap(1-a['direction']+3.14159) if a['speed']!=0 else 0.;errors.append(abs(wrap(float(x['downwind_map_rad'])-expected)));speeds.append(abs(float(x['speed'])-a['speed']))
 assert errors and max(errors)<1e-5 and max(speeds)==0
 out.append(dict(id=folder.name,raw_to_adapted_messages=count,fields_exact_except_required_direction_conversion=True,max_adapter_angle_error=angle,stationary_GMRF_pairs=len(errors),stationary_GMRF_max_angle_error=max(errors),stationary_GMRF_max_speed_error=max(speeds),scope='Stationary pre-goal frame/sign and message preservation check; moving transform interpolation and global wind-field accuracy not asserted.'))
(O/'WIND_INPUT_FRAME_QA.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
