#!/usr/bin/env bash
set -Ee -o pipefail
source /opt/ros/humble/setup.bash
source /home/zyc/ros2_ws/install/setup.bash
source /home/zyc/pmfs_official_alignment_r5_20261009/ws/install/setup.bash
source /home/zyc/pmfs_clean_c1_preparation_r6_20261009/ws/install/setup.bash
set -u
export LD_LIBRARY_PATH=/home/zyc/pmfs_clean_c1_preparation_r6_20261009/ws/install/gaden_common/lib:/home/zyc/pmfs_clean_c1_preparation_r6_20261009/ws/build/gaden_common/third_party/gaden_core/third_party/libbsc:${LD_LIBRARY_PATH:-}
export ROS_DOMAIN_ID=226 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
unset GADEN_RNG_SEED
export AMENT_PREFIX_PATH=/home/zyc/ros2_ws/native_pmfs_full20_20261014/D1/overlay:${AMENT_PREFIX_PATH}
exec python3 -B /home/zyc/ros2_ws/native_pmfs_wind_recovery_20261014/D1/runtime_driver.py
