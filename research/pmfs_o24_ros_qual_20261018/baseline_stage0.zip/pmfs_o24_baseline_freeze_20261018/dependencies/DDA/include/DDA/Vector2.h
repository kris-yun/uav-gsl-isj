#pragma once
#include <math.h>
#include <functional>

namespace DDA
{

    class Vector2;
    inline Vector2 operator/(const Vector2& vec, const float& other);

    class Vector2
    {
    public:
        float x, y;

        Vector2()
        {
            x = 0;
            y = 0;
        }
        Vector2(const float& x, const float& y)
        {
            this->x = x;
            this->y = y;
        }

        inline Vector2 operator+(const Vector2& other) const
        {
            return Vector2(x + other.x, y + other.y);
        }
        inline Vector2 operator-(const Vector2& other) const
        {
            return Vector2(x - other.x, y - other.y);
        }
        inline void operator+=(const Vector2& other)
        {
            x += other.x;
            y += other.y;
        }
        inline void operator-=(const Vector2& other)
        {
            x -= other.x;
            y -= other.y;
        }
        inline Vector2 operator-()
        {
            return Vector2(-x, -y);
        }

        // other stuff
        inline float dot(const Vector2& other) const
        {
            return x * other.x + y * other.y;
        }

        inline float norm() const
        {
            return std::sqrt(x * x + y * y);
        }

        inline Vector2 normalized() const
        {
            float n = norm();
            if (n == 0)
                return {0, 0};

            return *this / n;
        }

        inline void normalize()
        {
            float n = norm();
            if (n != 0)
            {
                x /= n;
                y /= n;
            }
        }

        inline Vector2 rotate(float signedAngleRadians) const
        {
            float c = std::cos(signedAngleRadians);
            float s = std::sin(signedAngleRadians);
            return {x * c - y * s, x * s + y * c};
        }
    };

    // scalar multiplication
    inline Vector2 operator*(const Vector2& vec, const float& other)
    {
        return Vector2(vec.x * other, vec.y * other);
    }
    inline Vector2 operator*(const float& other, const Vector2& vec)
    {
        return vec * other;
    }

    inline Vector2 operator/(const Vector2& vec, const float& other)
    {
        return Vector2(vec.x / other, vec.y / other);
    }
    
} // namespace DDA

template<>
struct std::hash<DDA::Vector2>
{
    size_t operator()(const DDA::Vector2& vec) const
    {
        return *(size_t*) &vec.x + (*(size_t*)(&vec.y) << 32);
    }
};