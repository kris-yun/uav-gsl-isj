#!/usr/bin/env python3
import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPECTED_BINARY = "14133117b9d24502acc8e45ad7c72fbd668fbe867fd73aeee17b70e52cfbe938"
EXPECTED_CONTRACT = "MEACI_SEQUENTIAL_SPATIAL_REPLICATION_V4"
CASES = (
    "H01_seed0_inverse_v10_reservoir",
    "H01_seed1_inverse_v10_reservoir",
    "H02_seed0_inverse_v10_reservoir",
    "H02_seed1_inverse_v10_reservoir",
    "H03_seed0_inverse_v10_reservoir",
    "H03_seed1_inverse_v10_reservoir",
)


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    binary_hash = digest(ROOT / "source" / "gsl_actionserver_node")
    assert binary_hash == EXPECTED_BINARY, binary_hash
    rows = []
    for case in CASES:
        run = ROOT / "closed_loop" / case
        manifest = json.loads((run / "runtime_manifest.json").read_text(encoding="utf-8"))
        evaluation = json.loads((run / "meaci_evaluation.json").read_text(encoding="utf-8"))
        assert manifest["algorithm_sha256"] == EXPECTED_BINARY
        assert manifest["contract"] == EXPECTED_CONTRACT
        assert str(manifest["steps_source_update"]) == "3"
        assert evaluation["development_gate_pass"] is True
        assert evaluation["pmfs_paper_metric_improvement_fraction"] >= 0.10
        tag = evaluation["update_tag"]
        with (run / "tadm" / f"meaci_events_update_{tag}.csv").open(
            newline="", encoding="utf-8"
        ) as handle:
            events = list(csv.DictReader(handle))
        rows.append(
            {
                "case": case,
                "accepted_update": int(tag),
                "events": len(events),
                "last_sim_time_s": max(float(event["sim_time"]) for event in events),
                "native_error_m": evaluation["native"]["pmfs_top5_error_m"],
                "meaci_error_m": evaluation["meaci"]["pmfs_top5_error_m"],
                "gain_fraction": evaluation["pmfs_paper_metric_improvement_fraction"],
                "pass": True,
            }
        )
    native_mean = sum(row["native_error_m"] for row in rows) / len(rows)
    meaci_mean = sum(row["meaci_error_m"] for row in rows) / len(rows)
    gains = sorted(row["gain_fraction"] for row in rows)
    verification = {
        "contract": "MEACI_V10_FROZEN_EVIDENCE_VERIFICATION_V1",
        "status": "PASS",
        "binary_sha256": binary_hash,
        "run_contract": EXPECTED_CONTRACT,
        "case_count": len(rows),
        "pass_count": sum(row["pass"] for row in rows),
        "pooled_native_mean_m": native_mean,
        "pooled_meaci_mean_m": meaci_mean,
        "pooled_improvement_fraction": (native_mean - meaci_mean) / native_mean,
        "minimum_gain_fraction": gains[0],
        "median_gain_fraction": (gains[2] + gains[3]) / 2.0,
        "maximum_gain_fraction": gains[-1],
        "cases": rows,
    }
    (ROOT / "FREEZE_VERIFICATION.json").write_text(
        json.dumps(verification, indent=2) + "\n", encoding="utf-8"
    )
    entries = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.tsv":
            entries.append(f"{digest(path)}\t{path.relative_to(ROOT).as_posix()}")
    (ROOT / "SHA256SUMS.tsv").write_text("\n".join(entries) + "\n", encoding="utf-8")
    print(json.dumps(verification, indent=2))


if __name__ == "__main__":
    main()
