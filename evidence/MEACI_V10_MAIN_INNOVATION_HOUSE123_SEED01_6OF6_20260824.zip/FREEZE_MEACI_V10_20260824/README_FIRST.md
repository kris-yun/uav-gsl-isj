# ME-ACI V10 main-innovation freeze

Status: **House01/House02/House03 x seeds 0/1 = 6/6 PASS** under the original PMFS final-error definition.

- Frozen online binary SHA-256: `14133117b9d24502acc8e45ad7c72fbd668fbe867fd73aeee17b70e52cfbe938`
- Run contract: `MEACI_SEQUENTIAL_SPATIAL_REPLICATION_V4`
- Formula marker: `inverse_transport_sequential_replication_v3`
- Source-update cadence: `stepsSourceUpdate=3`
- Maximum run budget: 300 simulation seconds
- Primary metric: PMFS `ExpectedValue(sourceProbability, 0.05)` localization error
- Pooled mean error: **4.7823 m -> 2.8220 m (40.99% reduction)**
- Worst individual gain: **22.38%**; all six exceed the frozen 10% threshold.

Read `FROZEN_METHOD_REPORT.md` for the mathematical contract, result matrix, limitations, and exact evidence paths.

