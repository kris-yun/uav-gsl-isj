# PMFS M1 Theory Freeze V3 — C2 反事实前向 + 有界条件可观测性

**日期：2026-09-10**  
**仓库：`kris-yun/uav-gsl-isj`**  
**目标分支：`g3-cstar-revise-before-exec-20260906`**  
**本包制作时分支 HEAD：`ec391ca56d5ccd501a8f43d64e711fa2d8fb9eda`**  
**状态：THEORY FREEZE FOR C2 EVIDENCE GENERATION；不授权新的闭环/多 seed。**

> 本包取代此前给出的 TSBIE / CMED 主路线建议。  
> TSBIE（transport-member 重加权）不得继续；CMED/FANS 只保留为 **C2 已通过后仍出现不可解释系统残差时的后备诊断**，当前不得实现。

---

## 这一次只做一件事

把仓库已经获得正证据的 C1：

```text
do(S=candidate)
→ exact candidate-specific transport
→ exact delayed/stateful FOPDT
→ counterfactual observation score
```

转成部署时可使用的 C2：

```text
geometry-only candidate
+ executed route history
+ timestamped PMFS-GMRF wind history
+ shared transport-member key
→ candidate-specific sparse-filament forward trace
→ persistent FOPDT
→ counterfactual likelihood
→ dimensionally-consistent observability/evidence bound
→ COMMIT / ABSTAIN diagnostic
```

**本轮不改 posterior，不改 planner，不碰 M2，不跑 closed loop。**

---

## 为什么现在这样做

仓库已有三个决定性事实：

1. **C1 正证据：** House01/02/03 的 2-source × 2-wind controlled factorial 中，禁止使用 same-source/same-wind trace 后，12/12 case 仍将 evaluator-only true source 排名第 1。  
   这支持“candidate-conditioned counterfactual source evidence”这个研究对象，但仅限 premise gate。

2. **早期条件可观测性不足：** source / source×wind interaction ratio 在 H02 60 s 为 0，H03 60 s 约为 1；到 180 s 后三 House 才都明显 > 1。  
   因此早期错误更新可能首先是“没有足够源判别信息却强行更新”，而不是必须先发明新的 shift detector。

3. **C2 continuum surrogate 已被否决：** local-wind continuum provider 的平均 temporal-shape correlation 仅 H01 0.234 / H02 0.183 / H03 0.159，并把稀疏 filament 预测成几乎持续非零暴露。  
   下一 provider 必须保留 sparse/intermittent filament transport 和 timestamped wind-field history。

---

## V3 新增的关键数学修正

当前 `counterfactual_likelihood.py::decide_with_observability()` 存在理论上不可接受的量纲问题：

```text
log-likelihood contrast（无量纲）
vs
member response std（浓度/响应单位）
```

不能直接相加比较。

V3 改成：

```text
所有 provider / transport discrepancy
→ 先在统一 residual metric 中校准
→ 再传播为 log-Bayes-factor perturbation bound
→ 最后只在 evidence space 中比较
```

最终形式：

\[
\underline B_t(c,d)
=
\min_k
\left[
\widehat B_t^k(c,d)-U_t^k(c,d)
\right].
\]

只有：

\[
\underline B_t(c,d)>0
\]

才能说当前观测对 `c > d` 的方向在 **声明的 transport members + 校准 provider error** 下仍然稳定。

否则：

```text
ABSTAIN_SOURCE_EVIDENCE
```

这只是“是否允许把当前观测解释为可靠源判别证据”的 gate，**不是 source-found declaration，也不是闭环成功。**

---

## Codex 阅读顺序

1. `01_PROJECT_STATE_AND_HARD_EXCLUSIONS.md`
2. `02_THEORY_FREEZE_SCM_ESTIMAND.md`
3. `03_EVIDENCE_BOUND_DERIVATION.md`
4. `04_DATA_REQUIREMENTS_AND_FACTORIAL_BANK.md`
5. `05_CODEX_C2_EXECUTION_GITHUB_CONTRACT.md`
6. `06_EVIDENCE_SCHEMAS.md`
7. `07_2026_TOP_VENUE_SUPPORT.md`
8. `08_GATE_CONTRACT.json`
9. `09_CODEX_HANDOFF_PROMPT.md`

---

## 最重要的执行原则

**任何决定实验结论的数据、脚本、配置、manifest、哈希、gate JSON 和报告都必须 commit + push 到 GitHub。**

如果原始 3-D GADEN volume 太大：

- 不允许只说“本地有”；
- 必须提交可复算的 route-sampled / block-sampled decision-critical trace；
- 提交原始外部数据的 SHA-256 / 路径 /生成命令 /环境 identity；
- 若决定性证据无法 Git-track，则输出 `STOP_EVIDENCE_NOT_GIT_TRACKABLE`。

Codex 完成后只需把 **branch + commit SHA** 给用户。用户会把提交号交回本窗口继续理论/证据审核。
