# 03 — 量纲一致的 Evidence Bound 推导

## 1. 统一到 whitened evidence space

设工作残差 covariance：

\[
\Sigma_D \succ 0.
\]

定义 whitened 变量：

\[
\widetilde z=\Sigma_D^{-1/2}z.
\]

对于 provider 预测：

\[
\widehat\mu_c
=
\widehat\mu_t^{c,k},
\qquad
\widehat\mu_d
=
\widehat\mu_t^{d,k}.
\]

观察：

\[
y=z_t^{obs}.
\]

Gaussian working log likelihood（去掉共同常数）：

\[
\widehat\ell(c)
=
-\frac12
\left\|
\Sigma_D^{-1/2}(y-\widehat\mu_c)
\right\|_2^2.
\]

pairwise log Bayes factor：

\[
\widehat B(c,d)
=
\widehat\ell(c)-\widehat\ell(d).
\]

现在 \(\widehat B\) 是无量纲 evidence quantity。

---

# 2. Provider discrepancy 也必须进入同一个尺度

设 evaluator-side exact GADEN/FOPDT response：

\[
\mu_c^\star.
\]

provider error：

\[
\delta_c=
\mu_c^\star-\widehat\mu_c.
\]

定义 whitened discrepancy radius：

\[
\left\|
\Sigma_D^{-1/2}\delta_c
\right\|_2
\le
\epsilon_c.
\]

\(\epsilon_c\) 是无量纲的 standardized response error。

它必须从 precommitted calibration evidence 得到，不允许由 source-localization gain 反调。

---

# 3. 从 response error 推到 log-evidence error

记：

\[
\rho_c
=
\left\|
\Sigma_D^{-1/2}(y-\widehat\mu_c)
\right\|_2,
\]

\[
\rho_d
=
\left\|
\Sigma_D^{-1/2}(y-\widehat\mu_d)
\right\|_2.
\]

对 candidate \(c\)：

\[
\ell^\star(c)-\widehat\ell(c)
=
r_c^\top\delta_c
-\frac12\|\delta_c\|^2
\]

（全部在 whitened coordinates 中）。

由 Cauchy–Schwarz：

\[
\left|
\ell^\star(c)-\widehat\ell(c)
\right|
\le
\rho_c\epsilon_c+\frac12\epsilon_c^2.
\]

同理对 \(d\)。

因此 pairwise evidence perturbation：

\[
\left|
B^\star(c,d)-\widehat B(c,d)
\right|
\le
U(c,d),
\]

其中：

\[
\boxed{
U(c,d)
=
\rho_c\epsilon_c+\frac12\epsilon_c^2
+
\rho_d\epsilon_d+\frac12\epsilon_d^2
}
\]

这解决了旧代码的单位错误：

```text
log likelihood
vs
ppm std
```

现在比较的是：

```text
log-BF
vs
log-BF perturbation bound
```

完全同一证据空间。

---

# 4. transport member uncertainty 不再用 variance penalty

对相同 transport key \(k\)：

\[
\widehat B_t^k(c,d).
\]

每个 \(k\) 都独立传播 provider error：

\[
U_t^k(c,d).
\]

定义 declared-member robust lower evidence：

\[
\boxed{
\underline B_t(c,d)
=
\min_{k\in\mathcal K}
\left[
\widehat B_t^k(c,d)-U_t^k(c,d)
\right]
}
\]

以及 upper evidence：

\[
\boxed{
\overline B_t(c,d)
=
\max_{k\in\mathcal K}
\left[
\widehat B_t^k(c,d)+U_t^k(c,d)
\right]
}
\]

注意：

这不是 M1H：

\[
mean-\lambda Var.
\]

也不是 TSBIE：

\[
\text{重新优化 member weights}.
\]

它只回答一个更小的问题：

> 在**已经声明的 transport intervention support** 中，每个 matched source counterfactual 的 evidence sign 是否都经得住已校准 provider error？

如果所有 member 共同处于错误 mechanism family，本 gate 仍可能失效；因此 C2 provider fidelity gate 必须先 PASS。

---

# 5. Selective Evidence Gate

对于 pair \(c,d\)：

### Robust support for c

\[
\underline B_t(c,d)>0
\]

才允许记录：

```text
ROBUST_EVIDENCE_C_OVER_D
```

### Robust support for d

\[
\overline B_t(c,d)<0
\]

记录：

```text
ROBUST_EVIDENCE_D_OVER_C
```

### 其它

\[
0\in[
\underline B_t(c,d),
\overline B_t(c,d)]
\]

记录：

```text
ABSTAIN_PAIRWISE_EVIDENCE
```

**V3 暂不规定 full-map posterior aggregation。**

Codex 必须先输出 pairwise matrix / sparse competitor diagnostics。
在本窗口审核数据前，不得自行设计新的 posterior weighting。

---

# 6. Counterfactual Observability Gate（不看 observation 方向）

candidate pair 的 nominal standardized separation：

\[
\widehat D_t^k(c,d)
=
\left\|
\Sigma_D^{-1/2}
(
\widehat\mu_t^{c,k}
-
\widehat\mu_t^{d,k}
)
\right\|_2.
\]

由 triangle inequality：

\[
D_t^{k,\star}(c,d)
\ge
\max\left(
0,\;
\widehat D_t^k(c,d)
-\epsilon_c-\epsilon_d
\right).
\]

定义：

\[
\boxed{
\underline D_t(c,d)
=
\min_k
\max
\left(
0,\;
\widehat D_t^k(c,d)-\epsilon_c-\epsilon_d
\right)
}
\]

对于 two Gaussian hypotheses、equal covariance、equal prior，最优 pairwise Bayes error 为：

\[
P_e
=
\Phi(-D/2).
\]

所以在工作模型成立时：

\[
\boxed{
P_{e,t}^{upper}(c,d)
=
\Phi
\left(
-\underline D_t(c,d)/2
\right)
}
\]

可以作为条件可观测性的可解释量：

- 接近 `0.5`：当前 prefix 基本无法区分；
- 越小：理论上越容易区分。

**不得根据 closed-loop gain 选择一个神奇的 D 阈值。**

首轮只报告连续曲线：

```text
D_lower(t)
pairwise_error_upper(t)
```

并与已有 60/120/180/240 s factorial signal 对照。

---

# 7. 为什么这比“180 s 后再更新”强

`180 s` 是 House123 development data 的现象，不可迁移。

新 quantity：

\[
\underline D_t(c,d)
\]

由当前：

- route；
- candidate pair；
- GMRF wind history；
- transport members；
- provider error calibration

共同决定。

所以不同 House、不同路线、不同风况可以在不同时间进入可观测状态。

这才是 conditional observability。

---

# 8. 当前不确定性语义必须拆开

当前 simulator sensor：

```text
FOPDT deterministic
noise_std = 0
```

因此暂时：

\[
U_{sensor}=0
\]

只要 exact FOPDT parity 已通过。

真正需要估计的是：

\[
U_{provider/model}.
\]

不要为了让公式“看起来完整”人为加一个 sensor uncertainty。

如果未来是真实传感器实验，再单独扩展：

\[
\Sigma_D=
\Sigma_{provider}
+
\Sigma_{sensor}.
\]

---

# 9. 当前 C1 中 sigma 的处理

已有 exact likelihood audit 曾使用：

> per-House median same-candidate fast/slow FOPDT RMS

作为 sigma rule。

这个量：

- 可以做 evaluator-side development normalization；
- **不是 sensor noise**；
- **不能作为跨 House online runtime parameter**。

Codex Phase 0 必须完整审计所有 `sigma/observation_sigma` 使用位置，并重新输出：

```text
SIGMA_SEMANTICS_AUDIT.json
```

C1 的 12/12 rank-1 正证据有 sigma-free `log1p MSE` 版本，因此 ranking premise 可以保留；
但任何置信区间/ABSTAIN claim 必须重新建立跨 House、truth-blind discrepancy calibration。
