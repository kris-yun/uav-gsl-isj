# 04 — 需要 Codex 生成并上传的数据

原则：

> 先用现有数据淘汰错误 provider；只有 provider 基本成立，才扩展 bank。

---

# Phase D0：现有资产审计，不生成新大数据

必须输出并 commit：

```text
evidence/m1_c2_v3/SIGMA_SEMANTICS_AUDIT.json
evidence/m1_c2_v3/C1_REPRODUCTION.json
evidence/m1_c2_v3/ASSET_PROVENANCE.json
docs/PMFS_M1_C2_V3_PHASE0_AUDIT.md
```

至少包含：

- current branch HEAD；
- build/runtime binary hashes；
- exact FOPDT parity；
- 当前所有 sigma 的名称、定义、单位、来源；
- C1 12/12 counterfactual rank reproduction；
- GMRF online wind vs GADEN evaluator wind 的信息边界；
- stale `PMFS/Simulations.cpp` build exclusion 生效证明。

若 C1 不能从当前分支 cleanly reproduce：

```text
STOP_C1_REPRODUCTION_FAILURE
```

---

# Phase D1：C2 provider 基础实现

provider 必须输出每个：

```text
(prefix, candidate, transport_member)
```

的：

```text
timestamp
candidate raw exposure
source-specific transport state identity
GMRF wind snapshot/content hash
route pose
member key
```

之后 exact FOPDT 单独生成 sensor response。

### 必须保留 sparse filament family

旧 local-wind continuum surrogate 已被结构性否定，不得修改参数复活。

### shared transport key

同一个 member key：

```text
U_k
```

必须可跨 candidate 复现。

需要 manifest：

```text
member_key
wind-history identity
filament RNG/substream identity
initial-condition identity
candidate-independent components
```

---

# Phase D2：用现有 12-case C1 microbank 做 provider falsification

在同样的 target `(source,wind)` / opposite-wind rule 上，比较：

```text
exact GADEN candidate response
vs
deployable C2 provider response
```

必须上传：

```text
evidence/m1_c2_v3/basic12/*.jsonl.gz
evidence/m1_c2_v3/basic12/C2_BASIC12_GATE.json
evidence/m1_c2_v3/basic12/C2_BASIC12_PAIRWISE.csv.gz
docs/PMFS_M1_C2_BASIC12_REPORT.md
```

每个 case 至少记录：

```text
exact response trace hash
provider response trace hash
observed target trace hash
exact true-vs-decoy score
provider true-vs-decoy score
score-sign agreement
provider standardized discrepancy
nonzero/intermittency summaries
```

### BASIC12 hard gate

必须满足：

```text
H01 = 4/4 sign preserved
H02 = 4/4 sign preserved
H03 = 4/4 sign preserved
```

即：

```text
12/12
```

否则：

```text
C2_BASIC12_NO_GO
```

立即停止，不生成 expanded bank。

---

# Phase D3：只有 BASIC12 PASS 才扩展 factorial bank

## 目标

当前 2-source × 2-wind 太小，无法稳定校准 provider discrepancy，也不能支撑 high-confidence cross-House bound。

新增 bank 必须仍然是：

```text
source × transport factorial
```

而不是 source 和 transport 各自随机、无法配对。

## 第一阶段建议规模

每个 House：

```text
4 source anchors
× 2 canonical wind regimes
× 2 filament/exogenous RNG keys
= 16 physical source×transport cells
```

三 House：

```text
48 cells
```

### source anchor 选择

必须在任何 GADEN 结果生成前：

- 从 frozen geometry-only PMFS candidate support 选；
- 使用 deterministic geometry-only selector；
- 不看 true source；
- 不看 gas；
- 不看 posterior；
- 不按 House 结果事后换点。

先 commit：

```text
evidence/m1_c2_v3/expanded_bank/PRECOMMITTED_SOURCE_ANCHORS.json
```

再生成数据。

### transport intervention identity

对每个 wind regime × RNG key：

```text
U_00, U_01, U_10, U_11
```

必须在四个 source anchors 上保持同一外生 intervention identity。

### route

第一轮沿当前 frozen source-blind geometry route 取样。

如果 D3 通过而后续 C2 在新 route 上失败，再扩第二 route；
现在不要一次性生成无穷 bank。

---

# Phase D4：GitHub 里必须有的“可复算充分数据”

原始 3-D GADEN volume 可以因为太大不进 Git，但以下必须进：

```text
per-cell route-sampled raw concentration/exposure trace
per-cell exact FOPDT response trace
per-cell provider raw exposure trace
per-cell provider FOPDT response trace
controller-visible GMRF wind-history identity/hash
evaluator GADEN wind identity/hash
route pose/timestamp trace
source-anchor manifest
transport-key manifest
environment/build manifest
```

建议格式：

```text
.jsonl.gz
.npz
.csv.gz
```

单文件建议控制在 25 MB 内。

若文件过大，分 shard：

```text
part-000.npz
part-001.npz
...
```

并提交：

```text
SHA256SUMS
MANIFEST.json
```

**不能只把大文件放 D:\ 或 VM 然后在 Markdown 里写路径。**

决定性 derived evidence 必须可从 GitHub 内容复算。

---

# Phase D5：discrepancy calibration 数据

对 calibration cell：

\[
e^{c,k}
=
\Sigma_D^{-1/2}
(
\mu_{exact}^{c,k}
-
\widehat\mu_{provider}^{c,k}
).
\]

输出：

```text
whitened_error_norm
prefix
source_anchor
transport_key
House
```

House 仅 evaluator-side。

### LOHO

三次：

```text
H01 + H02 calibrate → H03 test
H01 + H03 calibrate → H02 test
H02 + H03 calibrate → H01 test
```

不得使用 held-out House localization outcome 调任何参数。

### conformal / quantile 注意

如果使用 split-conformal radius，必须明确：

- guarantee 只在所声明 exchangeability 条件下成立；
- 不允许把“两个训练 House 的 cell exchangeability”夸成“任意新 House 的 formal coverage guarantee”。

建议同时报告：

```text
alpha = 0.10 primary diagnostic
alpha = 0.05 stress diagnostic
```

但不根据哪一个闭环表现好来选择。

---

# 我们下一次最需要 Codex 上传什么？

用户拿回本窗口时，最有价值的是以下五样：

1. `C2_BASIC12_GATE.json`
2. `SIGMA_SEMANTICS_AUDIT.json`
3. `C2_PROVIDER_DISCREPANCY_LOHO.json`
4. `PREFIX_OBSERVABILITY_60_120_180_240.json`
5. `PMFS_M1_C2_V3_FINAL_REPORT.md`

有这五份，我就能决定：

- C2 provider 是否成立；
- Gaussian residual law 是否继续；
- evidence bound 是否太宽/太窄；
- 是否应该进入 posterior shadow；
- 是否需要 CMED/FANS 后备诊断；
- 或者直接 C2 NO-GO 并重新找下一理论模块。
