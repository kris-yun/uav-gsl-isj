# 09 — 可直接复制给 Codex 的指令

你现在接手 `kris-yun/uav-gsl-isj` 的 PMFS causal M1。

目标分支：

`g3-cstar-revise-before-exec-20260906`

请把本压缩包中的：

`PMFS_M1_THEORY_FREEZE_V3_C2_EVIDENCE_BOUND_20260910/`

完整解压后先阅读全部文件，尤其：

- `01_PROJECT_STATE_AND_HARD_EXCLUSIONS.md`
- `03_EVIDENCE_BOUND_DERIVATION.md`
- `04_DATA_REQUIREMENTS_AND_FACTORIAL_BANK.md`
- `05_CODEX_C2_EXECUTION_GITHUB_CONTRACT.md`
- `08_GATE_CONTRACT.json`

## 你的任务

严格按照 V3 合同完成：

1. Phase 0 sigma/量纲/资产审计 + C1 12/12 复现；
2. 实现 deployable C2 sparse-filament candidate provider；
3. 只在 shadow/replay 上完成 BASIC12 falsification；
4. BASIC12 12/12 PASS 后才生成扩展 source×transport factorial bank；
5. 做 LOHO provider-discrepancy calibration；
6. 实现 dimensionally-consistent log-BF evidence bound 与 conditional-observability diagnostics；
7. 输出 60/120/180/240 s prefix evidence；
8. 所有 decision-critical code/evidence/report/manifests 必须 commit + push 到同一 GitHub 分支。

## 明确禁止

不要：

- 改 posterior；
- 改 planner；
- 跑新的 closed loop；
- 跑 multiseed；
- 做 M2；
- 做 CMED/FANS；
- 做 TSBIE；
- 做新的 pooling；
- 训练网络；
- 调 temperature/Top-K/blend；
- 用 House ID、true source、future gas/wind、GADEN ground-truth wind 做 online input；
- 使用 per-House runtime sigma；
- 为了 PASS 修改已经被拒绝的 local-wind continuum surrogate。

## 硬停止

如果：

- C1 不能复现；
- BASIC12 不是 12/12 sign preservation；
- Gaussian working residual law 明显失败；
- 发生 truth leakage；
- 决定性 evidence 无法 Git-track；

立即停止，保留反证，commit + push NO-GO 报告。

## GitHub 交付

每一 phase 都 commit + push。

最终回复用户只需提供：

- branch
- starting HEAD
- final HEAD
- commit SHA(s)
- key paths
- BASIC12 verdict
- expanded bank status
- residual-law verdict
- observability-bound verdict
- `C3_CLOSED_LOOP_AUTHORIZED = false`

用户会把 commit SHA 发回 ChatGPT 做下一轮理论与证据审核。
