# 06 — 建议 evidence schema

## A. `SIGMA_SEMANTICS_AUDIT.json`

```json
{
  "contract": "PMFS_M1_C2_V3_SIGMA_AUDIT",
  "sensor_noise_std_authoritative": 0.0,
  "items": [
    {
      "symbol": "observation_sigma",
      "code_path": "...",
      "current_semantics": "...",
      "unit": "...",
      "source": "...",
      "house_specific": false,
      "truth_dependent": false,
      "v3_decision": "RENAME_RECALIBRATE_OR_REJECT"
    }
  ],
  "old_observability_formula": {
    "rejected": true,
    "reason": "dimension mismatch"
  }
}
```

## B. `C2_BASIC12_GATE.json`

```json
{
  "contract": "PMFS_M1_C2_V3_BASIC12",
  "starting_head": "...",
  "provider_hash": "...",
  "fopdt_hash": "...",
  "by_house": {
    "H01": {"sign_preserved": 4, "cases": 4},
    "H02": {"sign_preserved": 4, "cases": 4},
    "H03": {"sign_preserved": 4, "cases": 4}
  },
  "total": {"sign_preserved": 12, "cases": 12},
  "verdict": "PASS_OR_NO_GO"
}
```

## C. `C2_PROVIDER_DISCREPANCY_LOHO.json`

```json
{
  "contract": "PMFS_M1_C2_V3_DISCREPANCY_LOHO",
  "response_transform": "log1p",
  "working_residual_law": "gaussian",
  "folds": [
    {
      "calibration_houses": ["H01", "H02"],
      "held_out_house": "H03",
      "covariance_rule": "...",
      "alpha_primary": 0.10,
      "epsilon_primary": 0.0,
      "held_out_coverage": 0.0,
      "held_out_whitened_errors": []
    }
  ],
  "residual_law_verdict": "PASS_OR_NO_GO"
}
```

## D. `PREFIX_OBSERVABILITY_60_120_180_240.json`

```json
{
  "contract": "PMFS_M1_C2_V3_PREFIX_OBSERVABILITY",
  "rows": [
    {
      "house": "H01",
      "prefix_s": 60,
      "candidate_c": "...",
      "candidate_d": "...",
      "member_key": "...",
      "D_hat": 0.0,
      "epsilon_c": 0.0,
      "epsilon_d": 0.0,
      "D_lower": 0.0,
      "pairwise_error_upper": 0.5,
      "bf_hat": 0.0,
      "bf_error_bound": 0.0,
      "bf_lower": 0.0,
      "bf_upper": 0.0,
      "evidence_state": "..."
    }
  ]
}
```

## E. `MANIFEST.json`

每个 evidence bundle 都必须有：

```json
{
  "contract": "...",
  "repo_commit": "...",
  "code_hashes": {},
  "binary_hashes": {},
  "environment_hashes": {},
  "input_files": [
    {"path": "...", "sha256": "..."}
  ],
  "output_files": [
    {"path": "...", "sha256": "..."}
  ],
  "commands": [],
  "runtime_information_boundary": {
    "allowed": [],
    "forbidden": []
  }
}
```
