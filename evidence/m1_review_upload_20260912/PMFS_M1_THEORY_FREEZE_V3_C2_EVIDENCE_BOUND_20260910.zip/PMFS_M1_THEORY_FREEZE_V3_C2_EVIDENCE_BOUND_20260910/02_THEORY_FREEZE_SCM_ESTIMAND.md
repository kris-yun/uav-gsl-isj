# 02 — Theory Freeze：SCM、估计对象与可检验假设

## 1. 结构因果模型

对时间前缀 \(t\)，定义 source-blind controller-visible history：

\[
H_t=
(E,\ A_{0:t},\ \widehat W_{0:t},\ R_{t_0}),
\]

其中：

- \(E\)：冻结 geometry / occupancy；
- \(A_{0:t}\)：已经执行的 route / sensing actions；
- \(\widehat W_{0:t}\)：PMFS 在线真正可获得的 timestamped GMRF 2-D wind-field history；
- \(R_{t_0}\)：窗口起点前的 persistent FOPDT state。

对 source candidate \(c\) 和 transport intervention/member key \(k\)：

\[
X^{c,k}_{0:t}
=
T_\phi
\left(
do(S=c),\ H_t,\ U_k
\right),
\]

其中 \(U_k\) 是预先声明、**跨所有 candidate 共用 key** 的外生 transport/randomness key。

关键点：

> “共用 \(U_k\)”不等于 source×transport interaction 被消掉。

允许：

\[
X^{c,k}\neq X^{d,k}
\]

而且差异可以随 \(k\) 很强。

然后使用固定传感器算子：

\[
\mu^{c,k}_{0:t}
=
G_\theta
\left(
X^{c,k}_{0:t};
R_{t_0}
\right).
\]

`G_theta` 必须与 authoritative FOPDT 完全一致并跨 prefix 保持 state。

---

## 2. 为什么 shared transport key 是因果比较的核心

要比较：

\[
do(S=c)
\quad\text{vs}\quad
do(S=d),
\]

应该尽可能保持其它外生因素相同。

所以 pairwise evidence 必须优先比较：

\[
(c,k)\quad\text{vs}\quad(d,k),
\]

而不是：

\[
(c,k_1)\quad\text{vs}\quad(d,k_2).
\]

这等价于 controlled common-random-number counterfactual coupling：

> 同一个 wind/transport intervention key 下只改变 source。

这比旧 M1G/M1H 的“对 member 结果做全局 centered/pooling”更直接，也保留 source×transport interaction。

---

## 3. 估计对象

本轮不把最终 posterior 本身称作因果 estimand。

基本估计对象是 pairwise source-intervention evidence：

\[
B_t^k(c,d)
=
\log
\frac{
p(Y_{0:t}^{obs}\mid do(S=c),H_t,U_k)
}{
p(Y_{0:t}^{obs}\mid do(S=d),H_t,U_k)
}.
\]

它回答：

> 在同一个已执行 route、同一个 controller-visible wind history、同一个 transport intervention key 下，只把 source 从 \(d\) 换成 \(c\)，当前实际观测更支持哪一个？

---

## 4. 工作观测模型

为了把 provider error 传播到统一证据空间，先定义：

\[
z = g(Y),
\]

首版固定使用：

\[
g(y)=\log(1+y),
\]

原因：

- 已有 C1 使用 `log1p` response error；
- 对稀疏、跨数量级浓度更稳定；
- 不新增可训练 transform。

对一个选定的 event/prefix vector：

\[
z_t^{obs}\mid c,k,H_t
\sim
\mathcal N(
\mu_t^{c,k},\Sigma_D).
\]

**重要语义：**

\(\Sigma_D\) 不是当前模拟器 sensor noise。

它是：

> provider + unresolved forward discrepancy 的 working residual law（工作残差分布）。

如果 Gaussian residual law 在 held-out evidence 上不成立：

```text
STOP_RESIDUAL_LAW_NO_GO
```

不得自动换 Student-t、网络或 House-specific sigma 救结果。

---

## 5. 可检验假设

### A1. Runtime-information legality

online provider 只允许：

- frozen geometry；
- geometry-only candidate；
- executed route prefix；
- timestamped PMFS GMRF wind fields；
- declared transport member key；
- frozen FOPDT parameters/state。

禁止：

- true source；
- House ID as feature；
- future gas/wind；
- GADEN ground-truth wind as runtime input；
- posterior rank；
- evaluator label；
- development-bank lookup。

### A2. Source intervention coupling

同一 \(k\) 必须映射到所有 candidate 的同一外生 transport intervention identity。

### A3. Sensor parity

candidate exposure 在进入 likelihood 前必须经过 exact delayed/stateful FOPDT；不得每 block 重置。

### A4. Provider fidelity is testable

deployable C2 provider 必须在 evaluator-only exact GADEN counterfactual assets 上独立验证。

### A5. Evidence abstention is not a time rule

COMMIT/ABSTAIN 只能来自 prediction/evidence quantity，不允许 `t>180s` 之类规则。

### A6. No closed-loop tuning

任何 discrepancy radius、covariance、alpha、window definition 都不能根据 final localization error 选择。

---

## 6. 两级 gate，而不是一个 posterior score

### Gate O：Counterfactual Observability（观测前）

只使用 candidate predictions，不看当前观测方向。

问题：

> 当前 route + wind prefix 在 transport/provider uncertainty 下，理论上是否已经把两个 candidate 分得足够开？

### Gate E：Selective Evidence（观测后）

使用实际 observation。

问题：

> 当前 observation 支持 \(c>d\) 的 log evidence，在 provider uncertainty 和声明 transport members 下符号是否仍稳定？

只有这两个 gate 的统计行为先在 shadow/replay 中成立，才讨论怎样接 posterior。
