# 01 — 当前项目状态与硬排除项

## A. CONFIRMED（只按仓库证据说）

### A1. M1 的可继续研究对象不是 raw-history invariant representation

当前冻结对象是：

\[
X^c_{0:t}
=
Transport(do(S=c),A_{0:t},U_{0:t},M)
\]

以及：

\[
Y_{0:t}=H(X^S_{0:t})+\epsilon.
\]

候选源通过 **相同已执行路线、相同因果风历史、相同传感器 law** 下的 source intervention 进行比较。

### A2. exact sensor law 已经被仓库复核

当前仿真传感器 FOPDT：

- `tau = 1.2 s`
- `dead time = 0.4 s`
- `dt = 0.2 s`
- 当前 source snapshot 中 `noise_std = 0`

所以：

> 当前 `observation_sigma` 绝不能再叫“sensor noise”。

如果 likelihood 需要 sigma，它只能被定义为：

**forward/model discrepancy scale（前向/模型失配尺度）或工作残差尺度**，

并且必须跨 House、truth-blind 地校准。

### A3. C1 counterfactual premise 已通过小规模受控验证

2 source × 2 wind × 3 House，共 12 个 case：

- target `(source, wind)` 不允许用其 same-source/same-wind candidate trace；
- 使用另一 wind intervention 的 candidate trace；
- 12/12 true source rank = 1。

这说明：

> 在 exact candidate-specific physical response 可用时，source identity 可以在受控 transport intervention 下保留。

但它 **不证明**：

- full-map；
- online deployability；
- closed-loop gain；
- cross-dataset generalization。

### A4. conditional observability 不是固定时间阈值

已有 factorial signal：

- H01：60 s 已有较强 source-over-interaction；
- H02：60 s source main effect = 0；
- H03：60 s source effect 与 source×wind interaction 约同量级；
- 180 s 后三个 House 才都出现 source-over-interaction > 1。

因此 `180 s` 只能是 development diagnostic，不得成为 online hard rule。

---

## B. REJECTED / FROZEN（不得变相复活）

| 路线 | 状态 | 本轮约束 |
|---|---|---|
| RMFE fixed-A / macro ranking | NO-GO | 不再用 fixed amplitude / similarity 主排名 |
| SCTT ordered causal-transport trajectory | NO-GO | 不把“保持时序顺序”本身当创新；shuffle 反例必须尊重 |
| PFDI offline reranking | online NO-GO | offline rank 改善不能充当闭环证据 |
| old M2 3-member marginalization | cross-House NO-GO | 不再把“多 member 平均”当主创新 |
| M1G geometric pooling | NO-GO | 禁止复活 |
| M1H mean-log − variance penalty | cross-House 1/3 | member agreement 不等于机制正确 |
| candidate-independent transport nuisance | falsified | 不再假定 transport effect 可被 centered away |
| transport-invariant residual | falsified | 禁止 |
| TSBIE member ambiguity/reweighting | withdrawn | shared support 全部错时仍可能 robustly wrong |
| PHIC proxy calibration | superseded | deterministic FOPDT 不是 bias-independent proxy |
| local-wind continuum C2 provider | rejected | structural response-family mismatch |
| temperature / Top-K / blend / reliability rescue | rejected | 禁止为结果调后验 |
| truth-conditioned selection/tuning | forbidden | 真值泄漏 |
| CMED/FANS | backup only | C2 通过后仍有系统残差才可重新评估 |
| M2 / planning | out of scope | M1-C2 未闭环前不碰 |

---

## C. 当前唯一主线

\[
\boxed{
do(S=c)
\rightarrow
\text{candidate-specific sparse transport}
\rightarrow
\text{stateful FOPDT}
\rightarrow
\text{counterfactual likelihood}
\rightarrow
\text{conditional observability/evidence gate}
}
\]

先把 C2 证据做完整，再决定是否进入 posterior/closed-loop。
