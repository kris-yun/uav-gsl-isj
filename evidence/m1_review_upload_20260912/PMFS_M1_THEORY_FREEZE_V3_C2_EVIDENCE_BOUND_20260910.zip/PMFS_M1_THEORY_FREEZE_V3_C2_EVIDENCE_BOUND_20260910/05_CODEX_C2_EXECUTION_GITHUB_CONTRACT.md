# 05 — Codex C2 执行 + GitHub 提交合同

## 0. 开始前

目标仓库：

```text
kris-yun/uav-gsl-isj
```

目标分支：

```text
g3-cstar-revise-before-exec-20260906
```

本理论包制作时 HEAD：

```text
ec391ca56d5ccd501a8f43d64e711fa2d8fb9eda
```

如果执行时 HEAD 已前进：

- 不 reset；
- 不 force push；
- 记录实际起始 HEAD；
- 先确认新提交没有推翻本合同的 frozen facts；
- 若存在冲突，STOP 并提交冲突报告。

---

# 1. GitHub 是唯一正式交接面

Codex 每完成一个 phase，都必须：

```text
git status
git diff
tests/audits
git add only relevant files
git commit
git push origin g3-cstar-revise-before-exec-20260906
```

不得把无关工作区修改混入。

每个 commit message 建议：

```text
m1 c2 v3 phase0 audit semantics
m1 c2 v3 implement filament counterfactual provider
m1 c2 v3 freeze basic12 gate
m1 c2 v3 add expanded factorial evidence
m1 c2 v3 freeze discrepancy and observability diagnostics
```

---

# 2. Phase 0 — 先审计，不改算法输出

任务：

### 2.1 sigma semantics audit

搜索：

```text
observation_sigma
sigma
sensor_discrepancy_bound
member_response_std
decide_with_observability
```

明确：

- 变量单位；
- 数据来源；
- 是否 House-specific；
- 是否 truth-dependent；
- 是否误称 sensor noise。

当前 simulator FOPDT noise_std=0，因此旧 `observation_sigma` 不得保留“sensor noise”语义。

### 2.2 dimensional bug freeze

正式写入：

```text
OLD_OBSERVABILITY_FORMULA_REJECTED = true
reason = "log-likelihood contrast cannot be compared to response-unit standard deviation"
```

旧函数可保留用于 historical test，但 C2 V3 不得使用它作为科学 gate。

### 2.3 reproduce C1

复现现有 exact counterfactual 12/12。

若失败，STOP。

### 2.4 push Phase 0

必须 push 后再继续。

---

# 3. Phase 1 — C2 deployable provider

## 3.1 允许输入

```text
geometry
candidate_xy/xyz from frozen geometry-only support
executed route prefix
timestamped PMFS GMRF 2-D wind-field history
declared transport member key
frozen transport physical parameters
```

## 3.2 禁止输入

```text
gas observation into provider
true source
source evaluator label
House ID as model feature
future wind
future gas
raw GADEN wind at runtime
posterior rank/probability
closed-loop distance
development-bank candidate trace lookup
```

## 3.3 必须有的状态

每个 candidate × member：

```text
persistent filament transport state
persistent source-specific state identity
persistent FOPDT state
```

FOPDT 可以在 likelihood layer 统一处理，但 state 绝不能每 block reset。

## 3.4 transport family

必须为 sparse/intermittent filament family。

不得复活：

```text
local-wind continuum surrogate
```

也不得通过：

```text
diffusion tuning
amplitude tuning
duration tuning
House-specific parameters
```

去救已否决 surrogate。

---

# 4. Phase 2 — BASIC12 falsification

不接 C++ posterior。

provider 只 shadow 输出。

使用现有 C1 exact assets，做 12-case 对照。

### hard requirement

```text
score-sign preserved = 12/12
```

任何 House < 4/4：

```text
STOP_C2_BASIC12_NO_GO
```

### 必须 push

代码 + raw route-sampled traces + hashes + report + gate JSON。

如果 NO-GO，也必须 push 反证，不允许删掉失败结果后继续改另一个 provider。

---

# 5. Phase 3 — expanded factorial bank（只在 BASIC12 PASS 后）

按 `04_DATA_REQUIREMENTS...` 生成。

### 先 commit anchor manifest，再跑数据

这是为了证明 source anchors 不是看结果挑的。

顺序必须：

```text
commit precommitted anchors
push
generate bank
audit
commit evidence
push
```

---

# 6. Phase 4 — residual law / discrepancy calibration

## 6.1 不允许 per-House online sigma

可以 evaluator-side 按 House 报告误差，
但 deployable residual model 参数必须从 training Houses / source-blind calibration rule 得到。

## 6.2 首版只测试一个模型

首版：

```text
log1p response + global/LOHO Gaussian working residual law
```

如果失败：

```text
STOP_RESIDUAL_LAW_NO_GO
```

不要自动换：

```text
Student-t
mixture
neural residual
House-specific covariance
```

这些要回来让用户/本窗口重新决定。

## 6.3 输出 whitened provider-error radius

用于 evidence bound。

---

# 7. Phase 5 — 只算 observability/evidence bound，不改 posterior

实现：

```text
pairwise_log_bf
provider_log_bf_error_bound
bf_lower
bf_upper
D_lower
pairwise_error_upper
ABSTAIN / robust-evidence diagnostic
```

### 关键代码要求

所有 quantities 必须 unit-tested。

至少测试：

1. provider error = 0 时 bound 收缩；
2. epsilon 增大时 BF interval 不得变窄；
3. identical candidates → D_lower = 0；
4. exact response 在 calibrated radius 内时 exact BF 必须落在 `[lower, upper]`；
5. candidate swap 满足：
   `B(c,d) = -B(d,c)`；
6. same transport key pairing 不可打乱；
7. FOPDT exact parity；
8. no future data；
9. no House/runtime truth leakage。

---

# 8. Prefix diagnosis

输出：

```text
60 s
120 s
180 s
240 s
```

的：

```text
D_lower
pairwise_error_upper
BF_lower/BF_upper（有 target observation 时）
abstention state
```

已有 factorial signal 只作为 sanity comparison：

- H02 60 s：不应该出现“非常强的 source observability”；
- H03 60 s：不应该出现“非常强的 source observability”；
- later prefixes 应在部分 pair 上增加 separation。

**不要为了满足这句话调参数。**

如果不符合，原样报告。

---

# 9. 本包不授权的下一步

以下全部禁止：

```text
posterior integration
planner integration
House123 new closed loop
multiseed
M2
CMED
TSBIE
new pooling
network
temperature/Top-K/blend
truth-tuned threshold
```

Codex 最终必须写：

```text
C3_CLOSED_LOOP_AUTHORIZED = false
```

用户会把 GitHub commit SHA 交回本窗口审核。
只有新审核明确授权，才进入下一阶段。

---

# 10. 最终回复用户的格式

Codex 最终只需要清楚给：

```text
branch:
starting HEAD:
final HEAD:
commits:
key files:
BASIC12 verdict:
expanded-bank status:
residual-law verdict:
observability-bound verdict:
C3 authorized: NO
```

不要只贴本地 Windows/VM 路径。
