# 07 — 2026 顶会理论支撑矩阵

本文件只把 **2026 顶级/一线会议论文**作为当前主理论锚点。
CLeaR/UAI 可以以后放 related work，但不承担“顶会主支撑”。

---

## 1. ICML 2026

### Arvind Raghavan, Elias Bareinboim
### *Causal Identification from Counterfactual Data: Completeness and Bounding Results*

正式信息：
- ICML 2026；
- Columbia CausalAI Lab 明确列为 `ICML-26`；
- ICML 2026 official downloads 列出该题目。

### 对项目真正支持的原则

它明确区分：

- 哪些 counterfactual quantity 可识别；
- 哪些不可精确识别；
- 不可精确识别时应给 bounds，而不是假装 point identification。

### 映射到 M1

我们的 C1/C2 不是该论文定理的直接实例。

但它强力支持我们现在的理论纪律：

> 明确写出 `do(S=c)` 的 counterfactual estimand；  
> 无法识别/分开 transport + provider uncertainty 时必须输出 bound/abstention，而不是继续强 source claim。

### 禁止表述

不能写：

> “Raghavan & Bareinboim 证明了 PMFS source intervention likelihood 可识别。”

没有这个结论。

---

## 2. ICLR 2026

### Alvin Heng, Harold Soh
### *Know When to Abstain: Optimal Selective Classification with Likelihood Ratios*

官方：
- ICLR 2026 proceedings 正式论文。

### 对项目最直接的启发

该工作从 Neyman–Pearson / likelihood-ratio 角度研究 selective classification：

> prediction system 不应对所有输入强制作答；  
> likelihood-ratio 信息可以用于设计 abstention / selection rule，尤其考虑 covariate shift。

### 映射到 M1

我们的任务不是分类器，因此不能照搬算法/最优性定理。

但它是目前最直接的顶会支撑之一：

> **用 evidence/likelihood-ratio space 决定何时 COMMIT，何时 ABSTAIN，比用 posterior entropy、time threshold 或 ppm variance 更有理论依据。**

这正对应 V3 的：

\[
\underline B_t(c,d)>0
\Rightarrow
\text{robust direction},
\]

否则 abstain。

---

## 3. ICML 2026

### Yorgos Felekis, Theodoros Damoulas, Paris Giampouras
### *Distributionally Robust Causal Abstractions*

正式信息：
- 43rd ICML 2026；
- peer reviewed；
- 研究环境变化、exogenous distribution misspecification 和 interventional consistency。

### 对项目的作用

用于支持：

> causal/interventional model 不能把 exogenous transport distribution 当作永远正确；环境 shift 和 model misspecification 必须显式处理。

### 为什么本轮不照搬它做新模块

我们已经失败过：

- global invariance；
- member pooling/reweighting。

所以本轮只借：

> **interventional consistency + misspecification awareness**

的理论原则。

不得复活 TSBIE / Wasserstein reweighting 作为当前 M1 主模块。

---

## 4. ICML 2026

### Tom Sprunck, Marcelo Pereyra, Tobias Liaudat
### *Bayesian model selection and misspecification testing in imaging inverse problems only from noisy and partial measurements*

正式信息：
- Proceedings of the 43rd ICML；
- PMLR 306；
- 2026。

### 为什么与 PMFS 非常相关

它研究的上层问题与我们相似：

> Bayesian inverse problem 在没有 ground truth 的运行环境里，如果 forward/statistical model misspecified，posterior 可以不可信；需要独立模型诊断。

### 映射到 M1

它支持：

> C2 provider 必须先经过独立 held-out forward-law fidelity / misspecification gate，再允许进入 PMFS posterior。

### 禁止表述

其 data-fission / imaging 定理不直接适用于 GADEN/FOPDT。
我们借的是 model-evaluation discipline，不复制其算法。

---

# 5. 辅助机器人桥接：RSS 2026

### Guangyang Zeng et al.
### *Provably Guaranteed Polytopic Uncertainty Quantification for SLAM*

RSS 2026 official proceedings。

它说明在机器人系统中：

> 不确定性可以被显式表示为可校准/可验证的 uncertainty set，再进入下游决策。

对本项目可作为机器人侧的 supporting reference：

> provider uncertainty 必须先形成可审计 bound，而不是把某个 variance 随意加到 likelihood 上。

它不是 M1 的因果理论来源。

---

# 结论

目前顶会文献足以支撑 **理论构造原则**：

\[
\text{counterfactual estimand}
+
\text{identification/bounding discipline}
+
\text{likelihood-ratio abstention}
+
\text{forward-model misspecification gate}.
\]

但真正新的 GSL/PMFS 部分必须由我们自己完成：

1. source-intervention SCM；
2. shared transport-key counterfactual coupling；
3. sensor-consistent candidate forward provider；
4. provider-error → log-BF bound 推导；
5. conditional observability；
6. House123 factorial / full-map / closed-loop falsification。

只有这些实验证据通过以后，才讨论“主创新已经成立”。
